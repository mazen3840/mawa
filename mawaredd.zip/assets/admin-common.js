/* =====================================================================
   مكونات لوحات الأدمن والسوبر أدمن (نفس الكود للاتنين، والفرق في الصلاحيات)
   ===================================================================== */
(function () {
'use strict';
const A = window.A = {};
const esc = M.esc, $ = (id, r) => (r || document).getElementById ? (r || document).getElementById(id) : null;

/* ---------- أدوات مشتركة ---------- */
const rangeHtml = p => `
  <label class="field"><span>من</span><input class="input" type="date" id="${p}From" dir="ltr" style="text-align:right"></label>
  <label class="field"><span>إلى</span><input class="input" type="date" id="${p}To" dir="ltr" style="text-align:right"></label>
  <div class="chips" id="${p}Q" style="margin:0 0 0 0;align-self:flex-end;padding-bottom:0">
    <button class="chip" data-d="0" type="button">اليوم</button><button class="chip" data-d="1" type="button">أمس</button>
    <button class="chip" data-d="7" type="button">7 أيام</button><button class="chip" data-d="30" type="button">30 يوم</button></div>`;
function bindRange(p, onChange, def) {
  const f = document.getElementById(p + 'From'), t = document.getElementById(p + 'To'), q = document.getElementById(p + 'Q');
  const set = d => {
    d = +d;
    if (d === 0) f.value = t.value = M.today();
    else if (d === 1) f.value = t.value = M.daysAgo(1);
    else { f.value = M.daysAgo(d - 1); t.value = M.today(); }
    M.$$('.chip', q).forEach(c => c.classList.toggle('on', +c.dataset.d === d));
  };
  q.addEventListener('click', e => { const b = e.target.closest('.chip'); if (b) { set(b.dataset.d); onChange(); } });
  [f, t].forEach(x => x.addEventListener('change', () => { M.$$('.chip', q).forEach(c => c.classList.remove('on')); onChange(); }));
  set(def == null ? 0 : def);
}
const val = id => (document.getElementById(id) || {}).value || '';
const sel = (id, opts, first) => `<select class="select" id="${id}">${first != null ? `<option value="">${first}</option>` : ''}${opts.map(o => `<option value="${esc(o[0])}">${esc(o[1])}</option>`).join('')}</select>`;
const loading = '<div class="empty"><span class="spin"></span></div>';
const pct = (a, b) => b ? Math.round(a * 100 / b) : 0;
A.admins = [];

/* =====================================================================
   لايف داشبورد (سوبر أدمن فقط)
   ===================================================================== */
A.liveTab = (el, o) => {
  el.innerHTML = `
  <div class="live-grid">
    <div class="live-stats" id="lvStats"></div>
    <div class="panel live-send">
      <div class="panel-h">${M.icon('bell')} إرسال إشعار بصوت</div>
      <div class="panel-b">
        <div class="filters" style="margin:0">
          <label class="field grow"><span>العنوان</span><input class="input" id="lvTitle" placeholder="مثال: تنبيه عاجل" maxlength="200"></label>
          <label class="field grow"><span>المستلم</span>
            <select class="select" id="lvTo"><option value="">— اختر —</option><option value="all">كل المستخدمين</option></select>
          </label>
        </div>
        <label class="field" style="margin-top:10px"><span>الرسالة</span>
          <textarea class="input" id="lvBody" rows="3" placeholder="نص الإشعار… الصوت هيفضل شغال عند المستلم لحد ما يضغط تم الاطلاع" maxlength="2000"></textarea>
        </label>
        <div style="margin-top:12px;display:flex;gap:8px;flex-wrap:wrap">
          <button type="button" class="btn primary" id="lvSend">${M.icon('send')} إرسال الآن</button>
          <span class="muted small" id="lvSendHint">الإشعار يظهر داخل النظام والصوت يتكرر حتى الاطلاع</span>
        </div>
      </div>
    </div>
    <div class="panel">
      <div class="panel-h" style="display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap">
        <span>${M.icon('pulse')} النشاط اللحظي</span>
        <span class="live-badge" id="lvBadge"><span class="live-dot"></span> مباشر</span>
      </div>
      <div class="panel-b" style="padding:0">
        <div class="live-feed" id="lvFeed"><div class="empty">جاري التحميل…</div></div>
      </div>
    </div>
    <div class="panel">
      <div class="panel-h">${M.icon('users')} متصلون الآن</div>
      <div class="panel-b" id="lvOnline"><div class="empty">—</div></div>
    </div>
  </div>`;

  let lastId = 0;
  let timer = null;
  let usersLoaded = false;
  const ROLE = M.ROLE || {};

  function eventIcon(t) {
    return ({ login: 'users', call: 'phone', visit: 'pin', sheet: 'file', notif: 'bell' }[t] || 'pulse');
  }
  function eventTone(t) {
    return ({ login: 'info', call: 'brand', visit: 'ok', sheet: 'violet', notif: 'warn' }[t] || '');
  }
  function renderStats(s) {
    s = s || {};
    document.getElementById('lvStats').innerHTML = [
      ['مكالمات اليوم', s.calls_today, 'phone'],
      ['زيارات اليوم', s.visits_today, 'pin'],
      ['تسجيلات دخول', s.logins_today, 'users'],
      ['متصلون', s.online, 'pulse'],
    ].map(([lab, val, ic]) =>
      `<div class="stat-card"><div class="stat-ic">${M.icon(ic)}</div><div class="stat-v ltr">${M.num(val || 0)}</div><div class="stat-l">${lab}</div></div>`
    ).join('');
  }
  function appendEvents(events, prepend) {
    const feed = document.getElementById('lvFeed');
    if (!events || !events.length) {
      if (!lastId) feed.innerHTML = `<div class="empty">${M.icon('pulse')} مفيش نشاط لسه — هيظهر هنا أول ما يحصل أي حاجة</div>`;
      return;
    }
    if (!lastId && !prepend) feed.innerHTML = '';
    const html = events.map(e => {
      const tone = eventTone(e.event_type);
      return `<div class="live-item ${tone}" data-id="${e.id}">
        <div class="live-item-ic">${M.icon(eventIcon(e.event_type))}</div>
        <div class="live-item-b">
          <div class="live-item-t">${M.esc(e.title)}</div>
          <div class="live-item-d muted small">${e.detail ? M.esc(e.detail) + ' · ' : ''}${M.esc(e.user_name || '')}${e.role ? ' · ' + M.esc((ROLE[e.role] || [e.role])[0]) : ''}</div>
        </div>
        <div class="live-item-time ltr muted small">${M.esc((e.created_at || '').slice(11, 19) || M.hm(e.created_at))}</div>
      </div>`;
    }).join('');
    if (prepend) {
      const empty = feed.querySelector('.empty');
      if (empty) empty.remove();
      feed.insertAdjacentHTML('afterbegin', html);
      // keep max ~80
      const items = feed.querySelectorAll('.live-item');
      for (let i = 80; i < items.length; i++) items[i].remove();
    } else {
      feed.innerHTML = html;
    }
    events.forEach(e => { if (e.id > lastId) lastId = e.id; });
  }
  function renderOnline(list) {
    const box = document.getElementById('lvOnline');
    if (!list || !list.length) { box.innerHTML = `<div class="empty">مفيش حد متصل دلوقتي</div>`; return; }
    box.innerHTML = `<div class="chips">${list.map(u =>
      `<span class="tag ${((ROLE[u.role] || ['', ''])[1])}">${M.esc(u.full_name)} <span class="muted">· ${M.esc((ROLE[u.role] || [u.role])[0])}</span></span>`
    ).join('')}</div>`;
  }

  async function loadUsers() {
    if (usersLoaded) return;
    const j = await M.get('notif_users');
    if (!j.success) return;
    const sel = document.getElementById('lvTo');
    (j.users || []).forEach(u => {
      if (u.id == M.user.id) return;
      const o = document.createElement('option');
      o.value = u.id;
      o.textContent = `${u.full_name} (${(ROLE[u.role] || [u.role])[0]})`;
      sel.appendChild(o);
    });
    usersLoaded = true;
  }

  async function tick(full) {
    try {
      const j = await M.get('live_feed', full || !lastId ? { limit: 40 } : { since_id: lastId, limit: 50 });
      if (!j.success) return;
      renderStats(j.stats);
      renderOnline(j.online_users);
      if (full || !lastId) appendEvents(j.events || [], false);
      else if (j.events && j.events.length) appendEvents(j.events, true);
      const badge = document.getElementById('lvBadge');
      if (badge) badge.classList.add('on');
    } catch (e) {
      const badge = document.getElementById('lvBadge');
      if (badge) badge.classList.remove('on');
    }
  }

  document.getElementById('lvSend').onclick = e => M.busy(e.currentTarget, async () => {
    const title = document.getElementById('lvTitle').value.trim();
    const body = document.getElementById('lvBody').value.trim();
    const to = document.getElementById('lvTo').value;
    if (!title || !body) return M.err('اكتب العنوان والرسالة');
    if (!to) return M.err('اختر المستلم');
    const payload = { title, body };
    if (to === 'all') payload.to_all = 1; else payload.to_user_id = +to;
    const j = await M.post('send_notification', payload);
    if (!j.success) return M.err(j.message);
    M.toast(j.message || 'تم الإرسال');
    document.getElementById('lvBody').value = '';
    tick(false);
  });

  function start() {
    loadUsers();
    tick(true);
    if (timer) clearInterval(timer);
    timer = setInterval(() => tick(false), 4000);
  }
  function stop() {
    if (timer) { clearInterval(timer); timer = null; }
  }

  // pause polling when tab hidden
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) stop();
    else if (el.classList.contains('on') || el.closest('.tabpane.on')) start();
  });

  return {
    load: () => { start(); },
    // optional cleanup if tabs switch away — polling is light so ok to leave
  };
};

A.loadAdmins = async () => {
  const j = await M.get('get_users');
  A.admins = j.success ? j.users.filter(u => u.role === 'admin' && +u.is_active) : [];
  return j;
};
const adminOpts = () => A.admins.map(a => [a.id, a.full_name]);

/* =====================================================================
   الأداء (نظرة عامة)
   ===================================================================== */
A.perfTab = (el, o) => {
  el.innerHTML = `<div class="panel"><div class="panel-b"><div class="filters">${rangeHtml('pf')}
      ${o.isSuper ? `<label class="field"><span>الفريق</span>${sel('pfAdmin', adminOpts(), 'كل الفرق')}</label>
      <label class="field"><span>الدور</span>${sel('pfRole', [['collector', 'محصل'], ['data_entry', 'مدخل بيانات'], ['admin', 'مشرف']], 'كل الأدوار')}</label>` : ''}
      <label class="field grow"><span>بحث بالاسم</span><input class="input" id="pfQ" type="search" placeholder="اسم الموظف"></label></div></div></div>
    <div id="pfKpis"></div><div id="pfTeams"></div><div id="pfBody">${loading}</div>`;
  let rows = [], sort = { k: 'calls', dir: -1 };
  const val2 = {
    name: r => r.full_name, team: r => r.admin_name || '', product: r => r.product_label || '', calls: r => r.calls.total, success: r => r.calls.success, ptp: r => r.calls.ptp,
    visits: r => r.visits.total, done: r => r.visits.completed, collected: r => r.visits.collected
  };
  async function load() {
    $('pfBody').innerHTML = loading;
    const j = await M.get('full_performance', { from: val('pfFrom'), to: val('pfTo'), admin_id: val('pfAdmin'), role: val('pfRole') });
    if (!j.success) { $('pfBody').innerHTML = `<div class="empty">${esc(j.message)}</div>`; return; }
    rows = j.users;
    const t = j.totals;
    $('pfKpis').innerHTML = `<div class="kpis">
      <div class="kpi"><small>مكالمات</small><b>${M.num(t.calls)}</b></div>
      <div class="kpi"><small>تواصل ناجح</small><b class="ok">${M.num(t.success)}</b></div>
      <div class="kpi"><small>تعهدات</small><b class="info">${M.num(t.ptp)}</b></div>
      <div class="kpi"><small>زيارات</small><b>${M.num(t.visits)}</b></div>
      <div class="kpi"><small>زيارات تمت</small><b class="ok">${M.num(t.completed)}</b></div>
      <div class="kpi"><small>المحصّل (ج.م)</small><b class="brass">${M.money(t.collected)}</b></div></div>`;
    renderTeams(); render();
  }
  function renderTeams() {
    if (!o.isSuper || val('pfAdmin')) { $('pfTeams').innerHTML = ''; return; }
    const T = {};
    rows.forEach(r => {
      const id = r.role === 'admin' ? r.id : (r.admin_id || 0);
      const name = r.role === 'admin' ? r.full_name : (r.admin_id ? r.admin_name : 'بدون فريق');
      const t = T[id] = T[id] || { name, n: 0, calls: 0, ok: 0, visits: 0, done: 0, col: 0 };
      t.n++; t.calls += r.calls.total; t.ok += r.calls.success; t.visits += r.visits.total; t.done += r.visits.completed; t.col += r.visits.collected;
    });
    const list = Object.values(T).sort((a, b) => b.col - a.col || b.calls - a.calls);
    $('pfTeams').innerHTML = `<div class="panel"><div class="panel-h">الفرق <small>${list.length} فريق</small></div><div class="table-wrap"><table class="t"><thead><tr><th>الفريق</th><th>الأعضاء</th><th>مكالمات</th><th>ناجحة</th><th>زيارات</th><th>تمت</th><th>المحصّل</th></tr></thead><tbody>
      ${list.map(t => `<tr><td><b>${esc(t.name)}</b></td><td class="num">${t.n}</td><td class="num">${M.num(t.calls)}</td><td class="num">${M.num(t.ok)}</td><td class="num">${M.num(t.visits)}</td><td class="num">${M.num(t.done)}</td><td class="num"><b style="color:var(--brass)">${M.money(t.col)}</b></td></tr>`).join('')}</tbody></table></div></div>`;
  }
  function render() {
    const q = val('pfQ').trim();
    let list = rows.filter(r => !q || r.full_name.includes(q) || (r.product_label || '').includes(q) || (r.admin_name || '').includes(q));
    const g = val2[sort.k];
    list.sort((a, b) => { const x = g(a), y = g(b); return (typeof x === 'string' ? x.localeCompare(y, 'ar') : x - y) * sort.dir; });
    if (!list.length) { $('pfBody').innerHTML = `<div class="panel"><div class="empty">${M.icon('users')}مفيش موظفين بالفلتر ده</div></div>`; return; }
    const th = (k, t) => `<th class="sortable ${sort.k === k ? (sort.dir > 0 ? 'asc' : 'desc') : ''}" data-k="${k}">${t}</th>`;
    $('pfBody').innerHTML = `<div class="panel"><div class="panel-h">أداء الأفراد <small>${list.length} موظف</small></div><div class="table-wrap"><table class="t"><thead><tr>
      ${th('name', 'الموظف')}${th('product', 'المنتج')}${o.isSuper ? th('team', 'الفريق') : ''}${th('calls', 'مكالمات')}${th('success', 'ناجحة')}${th('ptp', 'تعهد')}${th('visits', 'زيارات')}${th('done', 'تمت')}${th('collected', 'المحصّل')}</tr></thead><tbody>
      ${list.map(r => `<tr><td><b>${esc(r.full_name)}</b> ${M.roleTag(r.role)}${+r.is_active ? '' : ' <span class="tag bad">موقوف</span>'}</td>
        <td>${r.product_label ? `<span class="tag brand">${esc(r.product_label)}</span>` : `<span class="muted">—</span>`}</td>
        ${o.isSuper ? `<td class="muted">${esc(r.admin_name || '—')}</td>` : ''}
        <td class="num">${M.num(r.calls.total)}</td><td class="num">${M.num(r.calls.success)}</td><td class="num">${M.num(r.calls.ptp)}</td>
        <td class="num">${M.num(r.visits.total)}</td>
        <td class="num">${M.num(r.visits.completed)}${r.visits.total ? `<span class="bar"><i style="width:${pct(r.visits.completed, r.visits.total)}%"></i></span>` : ''}</td>
        <td class="num"><b style="color:var(--brass)">${M.money(r.visits.collected)}</b></td></tr>`).join('')}</tbody></table></div></div>`;
  }
  el.addEventListener('click', e => {
    const th = e.target.closest('th.sortable'); if (!th) return;
    sort = { k: th.dataset.k, dir: sort.k === th.dataset.k ? -sort.dir : (th.dataset.k === 'name' || th.dataset.k === 'team' ? 1 : -1) }; render();
  });
  bindRange('pf', load, 0);
  ['pfAdmin', 'pfRole'].forEach(id => { const e = document.getElementById(id); if (e) e.onchange = load; });
  document.getElementById('pfQ').addEventListener('input', M.debounce(render, 200));
  return { load };
};

/* =====================================================================
   الزيارات
   ===================================================================== */
A.visitsTab = (el, o) => {
  el.innerHTML = `<div class="panel"><div class="panel-b"><div class="filters">${rangeHtml('vt')}
      ${o.isSuper ? `<label class="field"><span>الفريق</span>${sel('vtAdmin', adminOpts(), 'كل الفرق')}</label>` : ''}
      <label class="field"><span>المحصل</span><select class="select" id="vtColl"><option value="">الكل</option></select></label>
      <label class="field"><span>الحالة</span>${sel('vtStatus', Object.entries(M.VISIT).map(([k, v]) => [k, v.t]), 'الكل')}</label>
      <div class="right row"><a class="btn primary" href="dataentry.html">${M.icon('plus')} إضافة زيارة</a><button class="btn" type="button" id="vtExp">${M.icon('download')} CSV</button></div></div></div></div>
    <div id="vtKpis"></div>
    <div class="panel"><div class="panel-h">الزيارات اليومية <small>آخر <span id="vtDays">7</span> يوم</small></div><div class="chart"><canvas id="vtChart"></canvas></div></div>
    <div id="vtBy"></div>
    <div class="panel"><div class="panel-h">الزيارات <small id="vtCount"></small></div><div id="vtList">${loading}</div></div>
    <div id="vtReg"></div>`;
  let chart = null, list = [];
  const params = () => ({ from: val('vtFrom'), to: val('vtTo'), admin_id: val('vtAdmin') });
  async function fillColls() {
    const j = await M.get('get_team_collectors'); if (!j.success) return;
    let cs = j.collectors; const a = val('vtAdmin');
    if (a) cs = cs.filter(c => String(c.admin_name) === (A.admins.find(x => x.id == a) || {}).full_name);
    const cur = val('vtColl');
    document.getElementById('vtColl').innerHTML = '<option value="">الكل</option>' + cs.map(c => `<option value="${c.id}">${esc(c.full_name)}</option>`).join('');
    document.getElementById('vtColl').value = cs.some(c => c.id == cur) ? cur : '';
  }
  async function load() {
    const p = params();
    $('vtList').innerHTML = loading;
    const days = Math.min(30, Math.max(7, Math.round((new Date(p.to) - new Date(p.from)) / 864e5) + 1));
    document.getElementById('vtDays').textContent = days;
    const [d, l, ch, rg] = await Promise.all([
      M.get('visits_dashboard', p),
      M.get('get_team_visits', Object.assign({ status: val('vtStatus'), collector_id: val('vtColl') }, p)),
      M.get('visits_chart', { days, admin_id: p.admin_id }),
      M.get('visits_by_region', p)
    ]);
    if (d.success) {
      $('vtKpis').innerHTML = `<div class="kpis"><div class="kpi"><small>إجمالي الزيارات</small><b>${M.num(d.total)}</b></div><div class="kpi"><small>تمت</small><b class="ok">${M.num(d.completed)}</b></div>
        <div class="kpi"><small>لسه</small><b class="warn">${M.num(d.pending)}</b></div><div class="kpi"><small>المحصّل (ج.م)</small><b class="brass">${M.money(d.collected)}</b></div></div>`;
      $('vtBy').innerHTML = d.by_collector.length ? `<div class="panel"><div class="panel-h">حسب المحصل</div><div class="table-wrap"><table class="t"><thead><tr><th>المحصل</th><th>إجمالي</th><th>تمت</th><th>لسه</th><th>المحصّل</th></tr></thead><tbody>
        ${d.by_collector.map(c => `<tr><td><b>${esc(c.collector_name)}</b></td><td class="num">${c.total}</td><td class="num">${c.completed}<span class="bar"><i style="width:${pct(c.completed, c.total)}%"></i></span></td><td class="num">${c.pending}</td><td class="num"><b style="color:var(--brass)">${M.money(c.collected)}</b></td></tr>`).join('')}</tbody></table></div></div>` : '';
    }
    if (ch.success) drawChart(ch.chart);
    list = l.success ? l.visits : [];
    $('vtCount').textContent = list.length >= 300 ? 'أول 300 زيارة' : list.length + ' زيارة';
    $('vtList').innerHTML = !l.success ? `<div class="empty">${esc(l.message)}</div>` : !list.length ? `<div class="empty">${M.icon('calendar')}مفيش زيارات في الفترة دي</div>` :
      `<div class="table-wrap"><table class="t"><thead><tr><th>العميل</th><th>المحصل</th><th>التاريخ</th><th>الحالة</th><th>المديونية</th><th>المحصّل</th><th></th></tr></thead><tbody>
      ${list.map(v => `<tr><td><b>${esc(v.client_name)}</b>${v.admin_notes ? `<div class="small muted">توجيه: ${esc(v.admin_notes)}</div>` : ''}${v.collector_notes ? `<div class="small muted">المحصل: ${esc(v.collector_notes)}</div>` : ''}</td>
        <td>${esc(v.collector_name || '—')}</td><td class="num">${M.dmy(v.visit_date)}${v.visited_at ? `<div class="small muted">تمت ${M.hm(v.visited_at)}</div>` : ''}</td><td>${M.visitTag(v.status)}</td>
        <td class="num">${M.money(v.total_debt)}</td><td class="num">${+v.collected_amount ? '<b style="color:var(--ok)">' + M.money(v.collected_amount) + '</b>' : '—'}</td>
        <td style="white-space:nowrap"><a class="btn sm" href="dataentry.html?edit_visit=${v.id}" title="تعديل">${M.icon('edit')}</a> <button class="btn sm danger" type="button" data-del="${v.id}" title="حذف">${M.icon('trash')}</button></td></tr>`).join('')}</tbody></table></div>`;
    if (rg.success && rg.regions.length) {
      const mx = Math.max(...rg.regions.map(r => r.total));
      $('vtReg').innerHTML = `<div class="panel"><div class="panel-h">توزيع الزيارات حسب المحافظة <small>من الرقم القومي للعميل</small></div><div class="table-wrap"><table class="t"><thead><tr><th>المحافظة</th><th>الزيارات</th><th>تمت</th><th>المحصّل</th></tr></thead><tbody>
        ${rg.regions.map(r => `<tr><td><b>${esc(r.name)}</b></td><td class="num">${r.total}<span class="bar"><i style="width:${pct(r.total, mx)}%;background:var(--brand)"></i></span></td><td class="num">${r.completed}</td><td class="num">${M.money(r.collected)}</td></tr>`).join('')}</tbody></table></div></div>`;
    } else $('vtReg').innerHTML = '';
  }
  function drawChart(data) {
    const cv = document.getElementById('vtChart'); if (!cv) return;
    if (typeof Chart === 'undefined') { cv.parentElement.style.height = 'auto'; cv.parentElement.innerHTML = '<div class="empty" style="padding:18px">تعذر تحميل مكتبة الرسم (محتاجة إنترنت)</div>'; return; }
    if (chart) chart.destroy();
    Chart.defaults.font.family = "'IBM Plex Sans Arabic', sans-serif";
    chart = new Chart(cv, {
      type: 'bar',
      data: { labels: data.map(d => d.label), datasets: [
        { label: 'إجمالي', data: data.map(d => d.total), backgroundColor: '#C9D6DE', borderRadius: 4 },
        { label: 'تمت', data: data.map(d => d.completed), backgroundColor: '#0B4A63', borderRadius: 4 }] },
      options: { responsive: true, maintainAspectRatio: false, plugins: { legend: { position: 'bottom', rtl: true, labels: { usePointStyle: true, boxWidth: 8 } } },
        scales: { y: { beginAtZero: true, ticks: { precision: 0 }, grid: { color: '#E7ECF0' } }, x: { grid: { display: false } } } }
    });
  }
  el.addEventListener('click', async e => {
    const b = e.target.closest('[data-del]'); if (!b) return;
    const v = list.find(x => x.id == b.dataset.del);
    if (!await M.confirm(`هتحذف زيارة "${v ? v.client_name : ''}"؟ الحذف نهائي.`, { title: 'حذف زيارة', danger: true, ok: 'حذف' })) return;
    const j = await M.post('delete_visit', { visit_id: b.dataset.del });
    if (j.success) { M.toast('تم حذف الزيارة'); load(); } else M.err(j.message);
  });
  document.getElementById('vtExp').onclick = e => M.busy(e.currentTarget, async () => { try { await M.download('export_visits', Object.assign({ status: val('vtStatus') }, params())); } catch (x) { M.err(x.message); } });
  bindRange('vt', load, 7);
  const a = document.getElementById('vtAdmin'); if (a) a.onchange = () => { fillColls().then(load); };
  ['vtColl', 'vtStatus'].forEach(id => document.getElementById(id).onchange = load);
  fillColls();
  return { load };
};

/* =====================================================================
   المكالمات
   ===================================================================== */
A.callsTab = (el, o) => {
  el.innerHTML = `<div class="panel"><div class="panel-b"><div class="filters">${rangeHtml('cl')}
      ${o.isSuper ? `<label class="field"><span>الفريق</span>${sel('clAdmin', adminOpts(), 'كل الفرق')}</label>` : ''}
      <label class="field"><span>الموظف</span><select class="select" id="clUser"><option value="">الكل</option></select></label>
      <div class="right"><button class="btn" type="button" id="clExp">${M.icon('download')} CSV</button></div></div></div></div>
    <div id="clKpis"></div>
    <div class="panel"><div class="panel-h">سجل المكالمات <small id="clCount"></small></div><div id="clList">${loading}</div></div>`;
  let allUsers = [];
  async function fillUsers() {
    if (!allUsers.length) { const j = await M.get('get_users'); if (!j.success) return; allUsers = j.users.filter(u => u.role !== 'super_admin'); }
    const a = val('clAdmin');
    const us = a ? allUsers.filter(u => u.admin_id == a || u.id == a) : allUsers;
    const cur = val('clUser');
    document.getElementById('clUser').innerHTML = '<option value="">الكل</option>' + us.map(u => `<option value="${u.id}">${esc(u.full_name)}</option>`).join('');
    document.getElementById('clUser').value = us.some(u => u.id == cur) ? cur : '';
  }
  async function load() {
    $('clList').innerHTML = loading;
    const p = { from: val('clFrom'), to: val('clTo'), admin_id: val('clAdmin') };
    const uid = val('clUser');
    const [d, l] = await Promise.all([M.get('dashboard', p), M.get('get_calls', { from: p.from, to: p.to, user_id: o.isSuper ? uid : '' })]);
    let calls = l.success ? l.calls : [];
    if (uid && !o.isSuper) calls = calls.filter(c => c.user_id == uid);
    if (o.isSuper && p.admin_id && !uid) { const ids = new Set(allUsers.filter(u => u.admin_id == p.admin_id || u.id == p.admin_id).map(u => +u.id)); calls = calls.filter(c => ids.has(+c.user_id)); }
    if (d.success) {
      const s = d.by_status || {};
      $('clKpis').innerHTML = `<div class="kpis"><div class="kpi"><small>إجمالي المكالمات</small><b>${M.num(d.total)}</b></div><div class="kpi"><small>تم التواصل</small><b class="ok">${M.num(s['تم التواصل بنجاح'] || 0)}</b></div>
        <div class="kpi"><small>تعهد بالسداد</small><b class="info">${M.num(s['تعهد بالسداد'] || 0)}</b></div><div class="kpi"><small>لم يرد</small><b class="bad">${M.num(s['لم يتم الرد'] || 0)}</b></div><div class="kpi"><small>مشغول</small><b class="warn">${M.num(s['الخط مشغول'] || 0)}</b></div></div>`;
    }
    $('clCount').textContent = calls.length >= 500 ? 'آخر 500 مكالمة' : calls.length + ' مكالمة';
    $('clList').innerHTML = !l.success ? `<div class="empty">${esc(l.message)}</div>` : !calls.length ? `<div class="empty">${M.icon('phone')}مفيش مكالمات في الفترة دي</div>` :
      `<div class="table-wrap"><table class="t"><thead><tr><th>الوقت</th><th>الموظف</th><th>العميل</th><th>التليفون</th><th>الحالة</th><th>الملاحظة</th></tr></thead><tbody>
      ${calls.map(c => `<tr><td class="num" style="white-space:nowrap">${M.dt(c.called_at)}</td><td>${esc(c.user_name)}</td><td><b>${esc(c.customer_name || '—')}</b></td><td>${M.ltr(c.phone)}</td><td>${M.callTag(c.status)}</td>
        <td class="small muted" style="max-width:260px">${esc(c.dcr || '')}${c.ptp ? `<div>تعهد: ${esc(c.ptp)} ${esc(c.ptp_date || '')}</div>` : ''}</td></tr>`).join('')}</tbody></table></div>`;
  }
  document.getElementById('clExp').onclick = e => M.busy(e.currentTarget, async () => { try { await M.download('export_calls', { from: val('clFrom'), to: val('clTo'), admin_id: val('clAdmin') }); } catch (x) { M.err(x.message); } });
  bindRange('cl', load, 0);
  const ca = document.getElementById('clAdmin'); if (ca) ca.onchange = () => fillUsers().then(load);
  document.getElementById('clUser').onchange = load;
  fillUsers();
  return { load };
};

/* =====================================================================
   المستخدمون
   ===================================================================== */
A.usersTab = (el, o) => {
  el.innerHTML = `<div class="panel"><div class="panel-h">${o.isSuper ? 'كل المستخدمين' : 'فريقي'}<button class="btn primary sm" type="button" id="usAdd">${M.icon('plus')} مستخدم جديد</button></div><div id="usList">${loading}</div></div>
    <div class="overlay" id="usM"><div class="sheet" role="dialog" aria-modal="true">
      <div class="sheet-h"><h3 id="usT"></h3><button class="btn quiet icon-btn" type="button" onclick="M.close('usM')" aria-label="إغلاق">${M.icon('x')}</button></div>
      <div class="sheet-b">
        <label class="field"><span>الاسم بالكامل *</span><input class="input" id="usName"></label>
        <div class="grid2"><label class="field"><span>اسم المستخدم *</span><input class="input" id="usUser" dir="ltr" style="text-align:right" autocapitalize="none" autocomplete="off"></label>
        <label class="field"><span id="usPassL">كلمة المرور *</span><input class="input" id="usPass" type="text" dir="ltr" style="text-align:right" autocomplete="new-password"></label></div>
        <div class="grid2"><label class="field"><span>التليفون</span><input class="input" id="usPhone" inputmode="tel" dir="ltr" style="text-align:right"></label>
        <label class="field"><span>الدور</span><select class="select" id="usRole">
          ${o.isSuper ? '<option value="admin">مشرف</option>' : ''}<option value="collector">محصل ميداني</option><option value="data_entry">مدخل بيانات</option>${o.isSuper ? '<option value="super_admin" id="usSuperOpt" hidden>سوبر أدمن</option>' : ''}</select></label></div>
        ${o.isSuper ? '<label class="field" id="usTeamF"><span>الفريق (المشرف المسؤول)</span><select class="select" id="usTeam"></select></label>' : ''}
        <label class="row" style="gap:8px;cursor:pointer"><input type="checkbox" id="usActive" checked style="width:18px;height:18px"> <span>الحساب فعّال</span></label>
      </div>
      <div class="sheet-f"><button class="btn" type="button" onclick="M.close('usM')">إلغاء</button><button class="btn primary" type="button" id="usSave">حفظ</button></div></div></div>`;
  let users = [], editing = null;
  async function load() {
    const j = await A.loadAdmins();
    if (!j.success) { $('usList').innerHTML = `<div class="empty">${esc(j.message)}</div>`; return; }
    users = j.users;
    const nameOf = id => (users.find(u => u.id == id) || {}).full_name || '—';
    $('usList').innerHTML = `<div class="table-wrap"><table class="t"><thead><tr><th>الاسم</th><th>اسم المستخدم</th><th>الدور</th><th>المنتج</th><th>العملاء المسندون</th>${o.isSuper ? '<th>الفريق</th>' : ''}<th>آخر دخول</th><th></th></tr></thead><tbody>
      ${users.map(u => `<tr><td><b>${esc(u.full_name)}</b>${+u.is_active ? '' : ' <span class="tag bad">موقوف</span>'}<div class="small muted">${M.ltr(u.phone)}</div></td><td>${M.ltr(u.username)}</td><td>${M.roleTag(u.role)}</td>
        <td>${u.product_label ? `<span class="tag brand">${esc(u.product_label)}</span>` : `<span class="muted">—</span>`}</td><td class="num">${['collector', 'data_entry'].includes(u.role) ? M.num(u.client_count || 0) : '—'}</td>
        ${o.isSuper ? `<td class="muted">${u.admin_id ? esc(nameOf(u.admin_id)) : '—'}</td>` : ''}<td class="small muted num">${u.last_login ? M.dt(u.last_login) : 'لم يدخل'}</td>
        <td style="white-space:nowrap"><button class="btn sm" type="button" data-e="${u.id}">${M.icon('edit')}</button> ${u.id == M.user.id ? '' : `<button class="btn sm danger" type="button" data-d="${u.id}">${M.icon('trash')}</button>`}</td></tr>`).join('')}</tbody></table></div>`;
  }
  function team() {
    if (!o.isSuper) return;
    document.getElementById('usTeam').innerHTML = '<option value="">— بدون فريق —</option>' + A.admins.map(a => `<option value="${a.id}">${esc(a.full_name)}${a.product_label ? ' · ' + esc(a.product_label) : ''}</option>`).join('');
    const r = val('usRole'); document.getElementById('usTeamF').classList.toggle('hide', r === 'admin' || r === 'super_admin');
  }
  function openM(u) {
    editing = u;
    $('usT').textContent = u ? 'تعديل مستخدم' : 'مستخدم جديد';
    $('usName').value = u ? u.full_name : ''; $('usUser').value = u ? u.username : ''; $('usUser').readOnly = !!u;
    $('usPass').value = ''; $('usPassL').textContent = u ? 'كلمة مرور جديدة (اتركها فاضية لو مش هتغيّر)' : 'كلمة المرور *';
    $('usPhone').value = u ? (u.phone || '') : ''; $('usActive').checked = u ? !!+u.is_active : true;
    if (o.isSuper) { const so = document.getElementById('usSuperOpt'); so.hidden = !(u && u.role === 'super_admin'); }
    $('usRole').value = u ? u.role : 'collector'; $('usRole').disabled = !!u && !o.isSuper;
    team(); if (o.isSuper) document.getElementById('usTeam').value = u && u.admin_id ? u.admin_id : '';
    M.open('usM');
  }
  $('usAdd').onclick = () => openM(null);
  if (o.isSuper) $('usRole').onchange = team;
  $('usList').addEventListener('click', async e => {
    const eb = e.target.closest('[data-e]'), db = e.target.closest('[data-d]');
    if (eb) return openM(users.find(u => u.id == eb.dataset.e));
    if (db) {
      const u = users.find(x => x.id == db.dataset.d);
      if (!await M.confirm(`هتحذف "${u.full_name}"؟ لو عنده سجل شغل هيتوقف بدل ما يتحذف.`, { title: 'حذف مستخدم', danger: true, ok: 'حذف' })) return;
      const j = await M.post('delete_user', { id: u.id });
      if (j.success) { M.toast(j.message || 'تم الحذف'); load(); } else M.err(j.message);
    }
  });
  $('usSave').onclick = e => M.busy(e.currentTarget, async () => {
    const body = { full_name: $('usName').value.trim(), phone: $('usPhone').value.trim(), role: $('usRole').value, is_active: $('usActive').checked ? 1 : 0 };
    if (!body.full_name) return M.err('الاسم مطلوب');
    if (editing) body.id = editing.id; else { body.username = $('usUser').value.trim(); if (!body.username) return M.err('اسم المستخدم مطلوب'); if (!$('usPass').value) return M.err('كلمة المرور مطلوبة'); }
    if ($('usPass').value) body.password = $('usPass').value;
    if (o.isSuper) body.admin_id = val('usTeam') || 0;
    const j = await M.post('save_user', body);
    if (!j.success) return M.err(j.message);
    M.close('usM'); M.toast('تم الحفظ'); load();
  });
  return { load };
};

/* =====================================================================
   الشيتات
   ===================================================================== */
A.sheetsTab = el => {
  el.innerHTML = `<div class="panel"><div class="panel-h">شيتات العملاء <small>اللي رفعها الفريق</small></div><div id="shList">${loading}</div></div>`;
  async function load() {
    const j = await M.get('team_sheets');
    if (!j.success) { $('shList').innerHTML = `<div class="empty">${esc(j.message)}</div>`; return; }
    $('shList').innerHTML = !j.sheets.length ? `<div class="empty">${M.icon('file')}محدش رفع شيت لسه</div>` :
      `<div class="table-wrap"><table class="t"><thead><tr><th>الموظف</th><th>الملف</th><th>العملاء</th><th>اترفع</th><th>آخر تحميل</th></tr></thead><tbody>
      ${j.sheets.map(s => `<tr><td><b>${esc(s.full_name)}</b> ${M.roleTag(s.role)}</td><td class="small">${esc(s.filename)}</td><td class="num">${M.num(s.client_count)}</td><td class="num small">${M.dt(s.uploaded_at)}</td><td class="num small muted">${s.last_download_at ? M.dt(s.last_download_at) : '—'}</td></tr>`).join('')}</tbody></table></div>`;
  }
  return { load };
};

/* =====================================================================
   أهداف يومية + مهام
   ===================================================================== */
A.opsTab = (el, o) => {
  el.innerHTML = `
  <div class="panel"><div class="panel-h">الهدف اليومي للفريق</div><div class="panel-b">
    <div class="filters">
      <label class="field"><span>اليوم</span><input class="input" type="date" id="tgDate" dir="ltr" style="text-align:right"></label>
      <label class="field grow"><span>الموظف</span><select class="select" id="tgUser"><option value="">—</option></select></label>
      <label class="field"><span>هدف مكالمات</span><input class="input" type="number" id="tgCalls" min="0" value="20" dir="ltr" style="text-align:right"></label>
      <label class="field"><span>هدف زيارات</span><input class="input" type="number" id="tgVisits" min="0" value="10" dir="ltr" style="text-align:right"></label>
      <button class="btn primary" type="button" id="tgSave" style="align-self:flex-end">${M.icon('check')} حفظ الهدف</button>
    </div>
    <div id="tgList" style="margin-top:14px">${loading}</div>
  </div></div>
  <div class="panel" style="margin-top:14px"><div class="panel-h">مهام للموظفين</div><div class="panel-b">
    <div class="filters">
      <label class="field grow"><span>إلى</span><select class="select" id="tkTo"><option value="">—</option></select></label>
      <label class="field grow"><span>عنوان المهمة</span><input class="input" id="tkTitle" placeholder="مثال: راجع تعهدات اليوم"></label>
      <label class="field"><span>الاستحقاق</span><input class="input" type="date" id="tkDue" dir="ltr" style="text-align:right"></label>
    </div>
    <label class="field" style="margin-top:8px"><span>التفاصيل</span><textarea class="input" id="tkBody" rows="2" placeholder="اختياري"></textarea></label>
    <div style="margin-top:10px"><button class="btn primary" type="button" id="tkSend">${M.icon('send')} إرسال مهمة</button></div>
    <div id="tkList" style="margin-top:14px">${loading}</div>
  </div></div>`;

  document.getElementById('tgDate').value = M.today();
  document.getElementById('tkDue').value = M.today();

  async function fillUsers() {
    const j = await M.get('get_users');
    if (!j.success) return;
    const opts = (j.users || []).filter(u => +u.is_active !== 0 && u.role !== 'super_admin');
    const html = opts.map(u => `<option value="${u.id}">${esc(u.full_name)} (${esc((M.ROLE[u.role]||[u.role])[0])})${u.product_label ? ' · ' + esc(u.product_label) : ''}</option>`).join('');
    document.getElementById('tgUser').innerHTML = '<option value="">— اختر —</option>' + html;
    document.getElementById('tkTo').innerHTML = '<option value="">— اختر —</option>' + html;
  }

  async function loadTargets() {
    const date = document.getElementById('tgDate').value || M.today();
    const j = await M.get('team_daily_targets', { date });
    const box = document.getElementById('tgList');
    if (!j.success) { box.innerHTML = `<div class="empty">${esc(j.message)}</div>`; return; }
    if (!(j.rows||[]).length) { box.innerHTML = `<div class="empty">مفيش موظفين</div>`; return; }
    box.innerHTML = `<div class="table-wrap"><table class="t"><thead><tr><th>الموظف</th><th>المنتج</th><th>مكالمات</th><th>زيارات</th><th>الهدف</th><th></th></tr></thead><tbody>
      ${j.rows.map(r => {
        const ct = +(r.target&&r.target.calls_target||0), vt = +(r.target&&r.target.visits_target||0);
        const tid = r.target && r.target.id ? r.target.id : '';
        const prod = r.user.product_label || '—';
        return `<tr data-uid="${r.user.id}" data-tid="${tid}" data-calls="${ct}" data-visits="${vt}">
          <td><b>${esc(r.user.full_name)}</b><div class="muted small">${esc((M.ROLE[r.user.role]||[r.user.role])[0])}</div></td>
          <td>${prod !== '—' ? `<span class="tag brand">${esc(prod)}</span>` : `<span class="muted">—</span>`}</td>
          <td class="ltr num">${r.calls_done}${ct?` / ${ct}`:''}</td>
          <td class="ltr num">${r.visits_done}${vt?` / ${vt}`:''}</td>
          <td>${ct||vt ? `<span class="tag ok">${ct} مكالمة · ${vt} زيارة</span>` : `<span class="muted">بدون هدف</span>`}</td>
          <td class="nowrap">
            <button class="btn sm" type="button" data-tg-edit="${r.user.id}" title="تعديل">${M.icon('edit')}</button>
            ${tid ? `<button class="btn sm danger" type="button" data-tg-del="${tid}" data-uid="${r.user.id}" title="حذف">${M.icon('trash')}</button>` : ''}
          </td>
        </tr>`;
      }).join('')}
    </tbody></table></div>`;
  }

  async function loadTasks() {
    const j = await M.get('tasks_sent');
    const box = document.getElementById('tkList');
    if (!j.success) { box.innerHTML = `<div class="empty">${esc(j.message)}</div>`; return; }
    if (!(j.tasks||[]).length) { box.innerHTML = `<div class="empty">لسه مفيش مهام مبعوتة</div>`; return; }
    box.innerHTML = `<div class="list">${j.tasks.map(t => `
      <div class="item ${t.status==='done'?'s-ok':'s-pending'}">
        <div class="grow"><div class="item-t">${esc(t.title)}</div>
          <div class="item-s">إلى: ${esc(t.to_name||'—')}${t.due_date?' · استحقاق '+M.dmy(t.due_date):''}</div>
          ${t.body?`<div class="muted small" style="margin-top:4px">${esc(t.body)}</div>`:''}
        </div>
        <span class="tag ${t.status==='done'?'ok':'warn'}">${t.status==='done'?'تمت':'مفتوحة'}</span>
      </div>`).join('')}</div>`;
  }

  document.getElementById('tgSave').onclick = e => M.busy(e.currentTarget, async () => {
    const user_id = +document.getElementById('tgUser').value;
    if (!user_id) return M.err('اختر الموظف');
    const j = await M.post('set_daily_target', {
      user_id,
      target_date: document.getElementById('tgDate').value || M.today(),
      calls_target: +document.getElementById('tgCalls').value || 0,
      visits_target: +document.getElementById('tgVisits').value || 0,
    });
    if (!j.success) return M.err(j.message);
    M.toast(j.message || 'تم'); loadTargets();
  });
  document.getElementById('tgDate').onchange = loadTargets;
  document.getElementById('tgList').addEventListener('click', async e => {
    const ed = e.target.closest('[data-tg-edit]');
    if (ed) {
      const tr = ed.closest('tr');
      document.getElementById('tgUser').value = ed.dataset.tgEdit;
      document.getElementById('tgCalls').value = tr.dataset.calls || 0;
      document.getElementById('tgVisits').value = tr.dataset.visits || 0;
      document.getElementById('tgSave').scrollIntoView({ behavior: 'smooth', block: 'center' });
      M.toast('عدّل الأرقام واضغط حفظ الهدف');
      return;
    }
    const del = e.target.closest('[data-tg-del]');
    if (del) {
      if (!await M.confirm('هتمسح الهدف اليومي للموظف ده؟', { title: 'حذف الهدف', danger: true, ok: 'حذف' })) return;
      const j = await M.post('delete_daily_target', {
        id: +del.dataset.tgDel,
        user_id: +del.dataset.uid,
        target_date: document.getElementById('tgDate').value || M.today()
      });
      if (!j.success) return M.err(j.message);
      M.toast(j.message || 'تم الحذف');
      loadTargets();
    }
  });
  document.getElementById('tkSend').onclick = e => M.busy(e.currentTarget, async () => {
    const to_user_id = +document.getElementById('tkTo').value;
    const title = document.getElementById('tkTitle').value.trim();
    if (!to_user_id || !title) return M.err('اختار المستلم واكتب العنوان');
    const j = await M.post('create_task', {
      to_user_id, title,
      body: document.getElementById('tkBody').value.trim(),
      due_date: document.getElementById('tkDue').value || '',
    });
    if (!j.success) return M.err(j.message);
    M.toast((j.message || 'تم') + ' — الموظف يشوفها في صفحة شغلي'); document.getElementById('tkTitle').value=''; document.getElementById('tkBody').value=''; loadTasks();
  });

  return {
    load: async () => { await fillUsers(); loadTargets(); loadTasks(); }
  };
};

/* =====================================================================
   المنتجات (سوبر أدمن)
   ===================================================================== */
A.productsTab = (el) => {
  el.innerHTML = `
  <div class="panel"><div class="panel-h">المنتجات</div><div class="panel-b">
    <p class="muted small" style="margin-bottom:12px">المنتج هو اللي الفريق شغال عليه (تنمية، فاليو، مايلو، CIB، أمان…). اربط كل منتج بأدمن/فريق.</p>
    <div class="filters">
      <label class="field grow"><span>اسم المنتج</span><input class="input" id="prName" placeholder="مثال: تنمية"></label>
      <label class="field"><span>كود</span><input class="input" id="prCode" placeholder="TANMIYA" dir="ltr" style="text-align:right"></label>
      <button class="btn primary" type="button" id="prAdd" style="align-self:flex-end">${M.icon('plus')} إضافة</button>
    </div>
    <div id="prList" style="margin-top:14px">${loading}</div>
  </div></div>
  <div class="panel" style="margin-top:14px"><div class="panel-h">ربط فريق بمنتج</div><div class="panel-b">
    <div class="filters">
      <label class="field grow"><span>المنتج</span><select class="select" id="ptProd"><option value="">—</option></select></label>
      <label class="field grow"><span>المشرف / قائد الفريق</span><select class="select" id="ptAdmin"><option value="">—</option></select></label>
      <label class="field grow"><span>اسم الفريق (اختياري)</span><input class="input" id="ptName" placeholder="فريق الإسكندرية"></label>
      <button class="btn primary" type="button" id="ptLink" style="align-self:flex-end">ربط</button>
    </div>
    <div id="ptList" style="margin-top:14px">${loading}</div>
  </div></div>`;

  let products = [], teams = [];

  async function load() {
    const j = await M.get('list_products');
    if (!j.success) return M.err(j.message);
    products = j.products || []; teams = j.teams || [];
    document.getElementById('prList').innerHTML = !products.length ? `<div class="empty">مفيش منتجات</div>` :
      `<div class="list">${products.map(p => `
        <div class="item"><div class="grow"><div class="item-t">${esc(p.name)} ${p.code?`<span class="muted small ltr">${esc(p.code)}</span>`:''}</div>
          <div class="item-s">${+p.is_active?'نشط':'موقوف'}</div></div>
          <span class="tag ${+p.is_active?'ok':'warn'}">${+p.is_active?'فعّال':'موقوف'}</span></div>`).join('')}</div>`;
    document.getElementById('ptProd').innerHTML = '<option value="">—</option>' + products.filter(p=>+p.is_active).map(p=>`<option value="${p.id}">${esc(p.name)}</option>`).join('');
    document.getElementById('ptList').innerHTML = !teams.length ? `<div class="empty">لسه مفيش فرق مربوطة</div>` :
      `<div class="list">${teams.map(t => `
        <div class="item"><div class="grow"><div class="item-t"><span class="tag brand">${esc(t.product_name)}</span> · ${esc(t.admin_name)}</div>
          <div class="item-s">${esc(t.team_name||'فريق ' + t.admin_name)} · ${M.num(t.members_count||0)} عضو</div></div>
          <button class="btn sm danger" type="button" data-rm="${t.id}">حذف</button></div>`).join('')}</div>`;
  }

  document.getElementById('prAdd').onclick = e => M.busy(e.currentTarget, async () => {
    const name = document.getElementById('prName').value.trim();
    if (!name) return M.err('اكتب اسم المنتج');
    const j = await M.post('save_product', { name, code: document.getElementById('prCode').value.trim(), is_active: 1 });
    if (!j.success) return M.err(j.message);
    M.toast('تم'); document.getElementById('prName').value=''; document.getElementById('prCode').value=''; load();
  });
  document.getElementById('ptLink').onclick = e => M.busy(e.currentTarget, async () => {
    const product_id = +document.getElementById('ptProd').value;
    const admin_id = +document.getElementById('ptAdmin').value;
    if (!product_id || !admin_id) return M.err('اختار المنتج والمشرف');
    const j = await M.post('assign_product_team', { product_id, admin_id, team_name: document.getElementById('ptName').value.trim() });
    if (!j.success) return M.err(j.message);
    M.toast('تم الربط'); load();
  });
  document.getElementById('ptList').addEventListener('click', async e => {
    const b = e.target.closest('[data-rm]'); if (!b) return;
    if (!await M.confirm('هتشيل الربط؟', { title: 'تأكيد', ok: 'حذف', danger: true })) return;
    const j = await M.post('remove_product_team', { id: b.dataset.rm });
    if (j.success) { M.toast('تم'); load(); } else M.err(j.message);
  });

  return {
    load: async () => {
      const uj = await M.get('get_users');
      const admins = (uj.users||[]).filter(u => u.role === 'admin' || u.role === 'super_admin');
      document.getElementById('ptAdmin').innerHTML = '<option value="">—</option>' + admins.map(u=>`<option value="${u.id}">${esc(u.full_name)}</option>`).join('');
      await load();
    }
  };
};

})();
