/* =====================================================================
   موارد سيستم — دوال مشتركة لكل الصفحات
   ===================================================================== */
(function () {
'use strict';
const M = window.M = {};
M.API = 'api.php';
[
  ['manifest', 'manifest.webmanifest'],
  ['icon', 'assets/icons/favicon-32.png', '32x32'],
  ['icon', 'assets/icons/favicon-16.png', '16x16'],
  ['apple-touch-icon', 'assets/icons/apple-touch-icon.png']
].forEach(([rel, href, sizes]) => {
  let link = [...document.querySelectorAll('link[rel]')].find(item => item.rel === rel && (!sizes || item.sizes === sizes));
  if (!link) {
    link = document.createElement('link');
    link.rel = rel;
    if (sizes) link.sizes = sizes;
    document.head.appendChild(link);
  }
  link.href = href;
});
M.ENV = (location.hostname === 'localhost' || location.hostname === '127.0.0.1') ? 'local' : 'production';
M.safeStorage = {
  get(key) { try { return localStorage.getItem(key); } catch (e) { return null; } },
  set(key, value) { try { localStorage.setItem(key, value); } catch (e) {} },
  remove(key) { try { localStorage.removeItem(key); } catch (e) {} },
  parse(key, fallback = null) { try { return JSON.parse(localStorage.getItem(key) || 'null'); } catch (e) { return fallback; } }
};
M.token = M.safeStorage.get('auth_token');
M.user = M.safeStorage.parse('auth_user', null);
M.clearSession = () => {
  M.token = null;
  M.user = null;
  ['auth_token', 'auth_user'].forEach(key => M.safeStorage.remove(key));
  try { localStorage.removeItem('mawared_offline_q'); } catch (e) {}
};

/* ---------------- مؤشر حالة الشبكة ---------------- */
const netStyle = document.createElement('style');
netStyle.id = 'mawared-network-style';
netStyle.textContent = `
  #mawared-network-badge {
    position: fixed;
    left: 14px;
    bottom: 14px;
    z-index: 2000;
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 7px 12px;
    border-radius: 999px;
    font-size: 11px;
    font-weight: 700;
    background: rgba(11, 74, 99, 0.96);
    color: #fff;
    box-shadow: 0 10px 20px rgba(11, 74, 99, 0.18);
    border: 1px solid rgba(255,255,255,0.18);
    backdrop-filter: blur(6px);
    user-select: none;
  }
  #mawared-network-badge.offline {
    background: rgba(126, 43, 35, 0.96);
  }
`;
if (!document.getElementById('mawared-network-style')) document.head.appendChild(netStyle);
M.setNetworkBadge = () => {
  if (!document.body) return;
  let badge = document.getElementById('mawared-network-badge');
  if (!badge) {
    badge = document.createElement('div');
    badge.id = 'mawared-network-badge';
    document.body.appendChild(badge);
  }
  const online = navigator.onLine !== false;
  badge.textContent = online ? 'متصل' : 'بدون اتصال';
  badge.classList.toggle('offline', !online);
  badge.title = online ? 'الاتصال متاح — يتم العمل بشكل طبيعي' : 'البيانات محفوظة محليًا وسيتم المزامنة تلقائيًا عند العودة للإنترنت';
};
window.addEventListener('online', () => { M.setNetworkBadge(); if (typeof M.flushOffline === 'function') M.flushOffline(); });
window.addEventListener('offline', () => M.setNetworkBadge());
setTimeout(() => M.setNetworkBadge(), 150);

/* ---------------- أيقونات (خطوط بسيطة) ---------------- */
const ICONS = {
  pulse: '<circle cx="12" cy="12" r="3"/><path d="M12 2v2M12 20v2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M2 12h2M20 12h2M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41"/>',
  bell: '<path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/>',
  send: '<line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/>',
  search: '<circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>',
  phone: '<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/>',
  chat: '<path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>',
  pin: '<path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/>',
  user: '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
  users: '<path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
  check: '<polyline points="20 6 9 17 4 12"/>',
  x: '<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>',
  plus: '<line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>',
  edit: '<path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"/>',
  trash: '<polyline points="3 6 5 6 21 6"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6M14 11v6"/><path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/>',
  download: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>',
  upload: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/>',
  logout: '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/>',
  calendar: '<rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>',
  clock: '<circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/>',
  camera: '<path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/>',
  file: '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/>',
  card: '<rect x="1" y="4" width="22" height="16" rx="2" ry="2"/><line x1="1" y1="10" x2="23" y2="10"/>',
  down: '<polyline points="6 9 12 15 18 9"/>',
  refresh: '<polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/>',
  chart: '<line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/>',
  list: '<line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/>',
  shield: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
  briefcase: '<rect x="2" y="7" width="20" height="14" rx="2" ry="2"/><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"/>',
  copy: '<rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>',
  alert: '<path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>',
  nav: '<polygon points="3 11 22 2 13 21 11 13 3 11"/>',
  next: '<polygon points="5 4 15 12 5 20 5 4"/><line x1="19" y1="5" x2="19" y2="19"/>',
  home: '<path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>',
  info: '<circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/>',
  bolt: '<polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>',
  settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>',
  end: '<path d="M10.68 13.31a16 16 0 0 0 3.41 2.6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6A19.79 19.79 0 0 1 2.11 4.18 2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91"/><line x1="22" y1="2" x2="14" y2="10"/><line x1="14" y1="2" x2="22" y2="10"/>'
};
M.icon = (n, cls) => `<svg class="i ${cls || ''}" viewBox="0 0 24 24" aria-hidden="true">${ICONS[n] || ''}</svg>`;

/* ---------------- تنسيقات ---------------- */
M.esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
M.num = n => (Number(n) || 0).toLocaleString('en-US', { maximumFractionDigits: 0 });
M.money = n => (Number(n) || 0).toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 2 });
M.ymd = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
M.today = () => M.ymd(new Date());
M.daysAgo = n => { const d = new Date(); d.setDate(d.getDate() - n); return M.ymd(d); };
M.hm = s => (s || '').slice(11, 16);
M.dt = s => { s = s || ''; return s ? s.slice(0, 10).split('-').reverse().join('/') + ' ' + s.slice(11, 16) : '—'; };
M.dmy = s => (s || '').slice(0, 10).split('-').reverse().join('/');
M.debounce = (fn, ms = 300) => { let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); }; };
M.$ = (s, r) => (r || document).querySelector(s);
M.$$ = (s, r) => Array.from((r || document).querySelectorAll(s));
M.ltr = v => v ? `<span class="ltr num">${M.esc(v)}</span>` : '—';

M.ROLE = { super_admin: ['سوبر أدمن', 'brand'], admin: ['مشرف', 'brass'], collector: ['محصل ميداني', 'info'], data_entry: ['مدخل بيانات', 'violet'] };
M.roleTag = r => { const x = M.ROLE[r] || [r, '']; return `<span class="tag ${x[1]}">${M.esc(x[0])}</span>`; };

M.VISIT = {
  pending: { t: 'قيد الانتظار', tone: '', edge: 'pending' },
  done: { t: 'تمت الزيارة', tone: 'ok', edge: 'ok' },
  paid: { t: 'سدّد بالكامل', tone: 'ok', edge: 'ok' },
  partial: { t: 'دفع جزء', tone: 'info', edge: 'ok' },
  promise: { t: 'وعد بالسداد', tone: 'warn', edge: 'warn' },
  absent: { t: 'غير موجود', tone: 'bad', edge: 'bad' },
  refused: { t: 'رفض السداد', tone: 'bad', edge: 'bad' },
  wrong: { t: 'عنوان غلط', tone: 'warn', edge: 'warn' }
};
M.isDone = s => ['done', 'paid', 'partial'].includes(s);
M.isPending = s => !s || s === 'pending';
M.visitTag = s => { const v = M.VISIT[s || 'pending'] || { t: s, tone: '' }; return `<span class="tag ${v.tone}">${M.esc(v.t)}</span>`; };
M.visitEdge = s => 's-' + ((M.VISIT[s || 'pending'] || {}).edge || 'pending');
M.CALL = { 'تم التواصل بنجاح': ['تم التواصل', 'ok'], 'لم يتم الرد': ['لم يرد', 'bad'], 'الخط مشغول': ['مشغول', 'warn'], 'تعهد بالسداد': ['تعهد بالسداد', 'info'] };
M.callTag = s => {
  if (!s) return '<span class="muted">—</span>';
  if (M.CALL[s]) return `<span class="tag ${M.CALL[s][1]}">${M.CALL[s][0]}</span>`;
  if (s.startsWith('زيارة')) { const k = s.split(':')[1]; return `<span class="tag brand">زيارة${k ? ' · ' + M.esc((M.VISIT[k.trim()] || {}).t || k.trim()) : ''}</span>`; }
  return `<span class="tag">${M.esc(s)}</span>`;
};

const NO_LEGAL = ['', '0', 'لا يوجد', 'مفيش', 'مفيش حكم', 'لا'];
M.legal = c => {
  const num = String(c.legal_num || '').trim(), st = String(c.legal_status || '').trim();
  return { hasCase: !NO_LEGAL.includes(num), hasVerdict: !NO_LEGAL.includes(st), num, st };
};
M.waUrl = (phone, text) => {
  let p = String(phone || '').replace(/\D/g, '');
  if (p.startsWith('01')) p = '2' + p; else if (p.length === 10 && p.startsWith('1')) p = '20' + p;
  return 'https://wa.me/' + p + (text ? '?text=' + encodeURIComponent(text) : '');
};
M.telUrl = p => 'tel:' + String(p || '').replace(/[^\d+]/g, '');
M.mapsUrl = a => 'https://www.google.com/maps/search/?api=1&query=' + encodeURIComponent(a);
M.notes = d => String(d || '').split(' / ').map(x => x.trim()).filter(Boolean);

/* ---------------- حساب المديونية ---------------- */
// "رصيد الفائدة والغرامة" القادم من الشيت هو إجمالي المديونية بالفعل (شامل رصيد القرض)،
// مش الفوائد والغرامات لوحدها — فمينفعش نجمعه على رصيد القرض تاني (كان بيتضاعف المبلغ).
// المبلغ الحقيقي للفوائد والغرامات لوحدها بيتحسب من عمودي "الفائدة" و"الغرامة" المنفصلين في الشيت،
// أو بالفرق لو مش متاحين.
M.debt = c => {
  const loan = +c.loan_balance || 0;
  const totalField = +c.interest_fine_balance || 0;
  const total = totalField > 0 ? totalField : loan;
  const partsSum = (+c.interest || 0) + (+c.fine || 0);
  const fees = partsSum > 0 ? partsSum : Math.max(0, total - loan);
  return { loan, fees, total };
};

/* ---------------- الاتصال (MacroDroid لأندرويد + Pushcut لآيفون) ---------------- */
// أندرويد: Webhook من MacroDroid
// آيفون: Webhook من تطبيق Pushcut (بيشغّل إجراء اتصال على الجهاز)
// لو مفيش رابط: الطريقة العادية tel:
let _callSettings = null, _callBar = null, _callTimer = null, _callStart = 0;
M.loadCallSettings = async (force) => {
  if (_callSettings && !force) return _callSettings;
  const j = await M.get('get_call_settings');
  _callSettings = j.success
    ? { method: j.method || 'android', call_url: j.call_url || '', hangup_url: j.hangup_url || '', shortcut_name: j.shortcut_name || '' }
    : { method: 'android', call_url: '', hangup_url: '', shortcut_name: '' };
  return _callSettings;
};
const withPhone = (base, phone) => {
  const sep = base.includes('?') ? '&' : '?';
  return base + sep + 'phone=' + encodeURIComponent(phone);
};
// MacroDroid: GET بسيط يكفي
const fireWebhook = url => { try { fetch(url, { mode: 'no-cors', cache: 'no-store' }).catch(() => {}); } catch (e) {} };
// Pushcut: GET بالمعاملات + POST JSON (الاتنين عشان يغطي كل أنواع الـ Notification / Server Action)
const firePushcut = (url, phone) => {
  try {
    const full = phone ? withPhone(url, phone) : url;
    fetch(full, { mode: 'no-cors', cache: 'no-store' }).catch(() => {});
    if (phone) {
      fetch(url, {
        method: 'POST',
        mode: 'no-cors',
        cache: 'no-store',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone: String(phone) })
      }).catch(() => {});
    }
  } catch (e) {}
};

function hideCallBar() {
  if (_callBar) { _callBar.remove(); _callBar = null; }
  if (_callTimer) { clearInterval(_callTimer); _callTimer = null; }
}
function showCallBar(phone, name, canHangup) {
  hideCallBar();
  _callBar = document.createElement('div');
  _callBar.className = 'callbar';
  _callBar.innerHTML = `<div class="callbar-in"><span class="pulse"></span><div class="grow trunc"><b>مكالمة جارية${name ? ' — ' + M.esc(name) : ''}</b><div class="ltr num small">${M.esc(phone)}</div></div><span class="ltr num" id="callBarTime">00:00</span><button class="btn danger sm" type="button" id="callBarEnd">${M.icon('end')} ${canHangup ? 'إنهاء' : 'إخفاء'}</button></div>`;
  document.body.appendChild(_callBar);
  _callStart = Date.now();
  _callTimer = setInterval(() => {
    const s = Math.floor((Date.now() - _callStart) / 1000), t = _callBar && _callBar.querySelector('#callBarTime');
    if (t) t.textContent = String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0');
  }, 1000);
  _callBar.querySelector('#callBarEnd').onclick = () => M.endCall(canHangup);
}
M.endCall = async (canHangup) => {
  if (canHangup) {
    const s = await M.loadCallSettings();
    if (s.hangup_url) {
      if (s.method === 'iphone') firePushcut(s.hangup_url, '');
      else fireWebhook(s.hangup_url);
    }
  }
  hideCallBar();
  M.toast('تم إنهاء المكالمة');
};
// M.call: دايماً استخدم ده بدل روابط tel:
M.call = async (phone, name) => {
  phone = String(phone || '').trim();
  if (!phone) return M.err('لا يوجد رقم تليفون');
  const s = await M.loadCallSettings();
  if (s.call_url) {
    if (s.method === 'iphone') firePushcut(s.call_url, phone);
    else fireWebhook(withPhone(s.call_url, phone));
    showCallBar(phone, name, !!s.hangup_url);
  } else {
    location.href = M.telUrl(phone);
  }
};
M.callBtn = (phone, opts = {}) => phone ? `<button class="btn ${opts.cls != null ? opts.cls : 'primary'} ${opts.big ? 'lg' : opts.sm ? 'sm' : ''}" type="button" data-call="${M.esc(phone)}" data-call-name="${M.esc(opts.name || '')}">${M.icon('phone')} ${opts.label != null ? opts.label : 'اتصال'}${opts.showNum ? ' <span class="ltr num">' + M.esc(phone) + '</span>' : ''}</button>` : '';
document.addEventListener('click', e => {
  const b = e.target.closest('[data-call]');
  if (b) M.call(b.dataset.call, b.dataset.callName);
});

M.openCallSettings = async () => {
  const s = await M.loadCallSettings(true);
  let ov = document.getElementById('callSet');
  if (!ov) {
    ov = document.createElement('div');
    ov.id = 'callSet';
    ov.className = 'overlay';
    ov.innerHTML = `<div class="sheet" role="dialog" aria-modal="true" aria-labelledby="csTitle">
      <div class="sheet-h"><h3 id="csTitle">إعدادات الاتصال</h3><button class="btn quiet icon-btn" type="button" onclick="M.close('callSet')" aria-label="إغلاق">${M.icon('x')}</button></div>
      <div class="sheet-b">
        <p class="muted small">اختار نوع تليفونك عشان الاتصال يبقى تلقائي بضغطة واحدة من غير ما تفتح شاشة الاتصال بنفسك.</p>
        <div class="seg" id="csMethod" style="margin-bottom:14px">
          <button type="button" class="info" data-m="android">أندرويد (MacroDroid)</button>
          <button type="button" class="info" data-m="iphone">آيفون (Pushcut)</button>
        </div>

        <div id="csAndroid">
          <label class="field"><span>رابط بدء المكالمة</span><input class="input" id="csCall" type="url" dir="ltr" style="text-align:right" placeholder="https://trigger.macrodroid.com/..."></label>
          <p class="muted small" style="margin-top:-8px">هيتضاف رقم العميل آخر الرابط تلقائيًا (phone=...).</p>
          <label class="field"><span>رابط إنهاء المكالمة (اختياري)</span><input class="input" id="csHang" type="url" dir="ltr" style="text-align:right" placeholder="https://trigger.macrodroid.com/..."></label>
        </div>

        <div id="csIphone" class="hide">
          <label class="field"><span>رابط Pushcut لبدء المكالمة</span><input class="input" id="csCallIos" type="url" dir="ltr" style="text-align:right" placeholder="https://api.pushcut.io/.../notifications/..."></label>
          <label class="field"><span>رابط إنهاء المكالمة (اختياري)</span><input class="input" id="csHangIos" type="url" dir="ltr" style="text-align:right" placeholder="https://api.pushcut.io/..."></label>
          <div class="note" style="margin-top:4px">
            <small>طريقة الربط على الآيفون (مرة واحدة)</small>
            1) نزّل تطبيق <b>Pushcut</b> من الـ App Store وسجّل حساب.<br>
            2) من التطبيق: <b>Notifications</b> ← <b>+</b> ← سمّ الإشعار مثلاً «اتصال عميل».<br>
            3) ضيف إجراء <b>Call</b>، وفي خانة الرقم اختار <b>Notification Input</b> (أو Input / Text).<br>
            4) احفظ، بعدين من تفاصيل الإشعار انسخ <b>Webhook URL</b> والصقه فوق.<br>
            5) (اختياري) اعمل إشعار تاني لإنهاء المكالمة لو عايز زر إنهاء يشتغل من الموقع.<br>
            6) خلّي تطبيق Pushcut مفتوح في الخلفية أو مفعّل الإشعارات عشان الـ webhook يتنفّذ فورًا.
          </div>
        </div>
      </div>
      <div class="sheet-f"><button class="btn" type="button" onclick="M.close('callSet')">إلغاء</button><button class="btn primary" type="button" id="csSave">حفظ</button></div></div>`;
    document.body.appendChild(ov);
    const paintMethod = m => {
      M.$$('#csMethod button').forEach(b => b.classList.toggle('on', b.dataset.m === m));
      document.getElementById('csAndroid').classList.toggle('hide', m !== 'android');
      document.getElementById('csIphone').classList.toggle('hide', m !== 'iphone');
    };
    ov._paintMethod = paintMethod;
    document.getElementById('csMethod').addEventListener('click', e => { const b = e.target.closest('[data-m]'); if (b) paintMethod(b.dataset.m); });
    document.getElementById('csSave').onclick = e => M.busy(e.currentTarget, async () => {
      const activeBtn = ov.querySelector('#csMethod button.on');
      const method = activeBtn ? activeBtn.dataset.m : 'android';
      let call_url = '', hangup_url = '';
      if (method === 'iphone') {
        call_url = document.getElementById('csCallIos').value.trim();
        hangup_url = document.getElementById('csHangIos').value.trim();
      } else {
        call_url = document.getElementById('csCall').value.trim();
        hangup_url = document.getElementById('csHang').value.trim();
      }
      for (const u of [call_url, hangup_url]) if (u && !/^https:\/\//i.test(u)) return M.err('الرابط لازم يبدأ بـ https://');
      const j = await M.post('save_call_settings', { method, call_url, hangup_url, shortcut_name: '' });
      if (!j.success) return M.err(j.message);
      _callSettings = { method, call_url, hangup_url, shortcut_name: '' };
      M.close('callSet'); M.toast('تم الحفظ');
    });
  }
  // fill fields
  document.getElementById('csCall').value = s.method === 'android' ? (s.call_url || '') : '';
  document.getElementById('csHang').value = s.method === 'android' ? (s.hangup_url || '') : '';
  document.getElementById('csCallIos').value = s.method === 'iphone' ? (s.call_url || '') : (s.method === 'iphone' ? s.call_url : '');
  // if user previously had iphone, show urls in ios fields; if android show in android
  if (s.method === 'iphone') {
    document.getElementById('csCallIos').value = s.call_url || '';
    document.getElementById('csHangIos').value = s.hangup_url || '';
  } else {
    document.getElementById('csCall').value = s.call_url || '';
    document.getElementById('csHang').value = s.hangup_url || '';
    document.getElementById('csCallIos').value = '';
    document.getElementById('csHangIos').value = '';
  }
  ov._paintMethod(s.method || 'android');
  M.open('callSet');
};

/* ---------------- الاتصال بالسيرفر ---------------- */
M.logout = async () => {
  try { await fetch(M.API + '?action=logout', { method: 'POST', headers: { 'X-Auth-Token': M.token || '' } }); } catch (e) {}
  M.clearSession();
  location.replace('index.html');
};
M.guard = roles => {
  if (!M.token || !M.user || (roles && !roles.includes(M.user.role))) {
    M.clearSession();
    location.replace('index.html');
    return false;
  }
  return true;
};
M.api = async (path, opts = {}) => {
  opts.headers = Object.assign({}, opts.headers, { 'X-Auth-Token': M.token || '' });
  if (opts.body && typeof opts.body === 'object' && !(opts.body instanceof FormData)) {
    opts.headers['Content-Type'] = 'application/json';
    opts.body = JSON.stringify(opts.body);
  }
  let r;
  try { r = await fetch(M.API + path, opts); }
  catch (e) { return { success: false, network: true, message: 'مفيش اتصال بالسيرفر — اتأكد من النت وجرّب تاني' }; }
  if (r.status === 401 && !path.includes('action=login')) {
    M.clearSession();
    location.replace('index.html');
    return { success: false, message: 'انتهت الجلسة' };
  }
  try { return await r.json(); }
  catch (e) { return { success: false, message: 'رد غير متوقع من السيرفر (كود ' + r.status + ')' }; }
};
M.qs = o => { const p = new URLSearchParams(); Object.entries(o).forEach(([k, v]) => { if (v !== '' && v != null) p.set(k, v); }); return p.toString(); };
M.get = (action, params = {}) => M.api('?' + M.qs(Object.assign({ action }, params)));
M.post = (action, body = {}) => M.api('?action=' + action, { method: 'POST', body });
M.download = async (action, params = {}) => {
  let r;
  try { r = await fetch(M.API + '?' + M.qs(Object.assign({ action }, params)), { headers: { 'X-Auth-Token': M.token || '' } }); }
  catch (e) { throw new Error('مفيش اتصال بالسيرفر'); }
  if (!r.ok) { let j = {}; try { j = await r.json(); } catch (e) {} throw new Error(j.message || 'تعذر التحميل'); }
  const b = await r.blob();
  const m = (r.headers.get('Content-Disposition') || '').match(/filename="?([^";]+)"?/);
  const a = document.createElement('a');
  a.href = URL.createObjectURL(b); a.download = m ? m[1] : 'file';
  document.body.appendChild(a); a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 200);
};
M.busy = async (btn, fn) => {
  if (btn && btn.classList.contains('busy')) return;
  btn && btn.classList.add('busy');
  try { return await fn(); } finally { btn && btn.classList.remove('busy'); }
};

/* ---------------- إشعارات وتأكيد ---------------- */
let toastT;
M.toast = (msg, o = {}) => {
  let t = document.getElementById('toast');
  if (!t) { t = document.createElement('div'); t.id = 'toast'; t.className = 'toast'; t.setAttribute('role', 'status'); document.body.appendChild(t); }
  t.className = 'toast ' + (o.type || '');
  t.innerHTML = `<div><span>${M.esc(msg)}</span>${o.action ? `<button type="button">${M.esc(o.action.label)}</button>` : ''}</div>`;
  t.style.display = 'flex';
  if (o.action) t.querySelector('button').onclick = () => { t.style.display = 'none'; o.action.fn(); };
  clearTimeout(toastT);
  toastT = setTimeout(() => { t.style.display = 'none'; }, o.ms || (o.action ? 6000 : 3200));
};
M.err = m => M.toast(m || 'حصل خطأ', { type: 'bad', ms: 4500 });

M.confirm = (msg, o = {}) => new Promise(res => {
  const ov = document.createElement('div');
  ov.className = 'overlay confirm on';
  ov.innerHTML = `<div class="sheet" role="dialog" aria-modal="true"><div class="sheet-b"><h3 style="font-size:17px;font-weight:600;margin-bottom:6px">${M.esc(o.title || 'تأكيد')}</h3><p class="muted">${M.esc(msg)}</p></div>
    <div class="sheet-f"><button class="btn" data-r="0">إلغاء</button><button class="btn ${o.danger ? 'ok' : 'primary'}" data-r="1" style="${o.danger ? 'background:var(--bad);border-color:var(--bad)' : ''}">${M.esc(o.ok || 'تأكيد')}</button></div></div>`;
  ov.addEventListener('click', e => { const b = e.target.closest('[data-r]'); if (b) { ov.remove(); res(b.dataset.r === '1'); } });
  document.body.appendChild(ov);
  ov.querySelector('[data-r="0"]').focus();
});

/* ---------------- نوافذ ---------------- */
M.open = id => { const e = document.getElementById(id); if (e) { e.classList.add('on'); const b = e.querySelector('.sheet-b'); if (b) b.scrollTop = 0; } };
M.close = id => { const e = document.getElementById(id); if (e) e.classList.remove('on'); };
document.addEventListener('keydown', e => {
  if (e.key !== 'Escape') return;
  const lb = document.getElementById('lightbox');
  if (lb && lb.classList.contains('on')) { lb.classList.remove('on'); return; }
  const o = M.$$('.overlay.on').pop(); if (o) o.classList.remove('on');
});
document.addEventListener('click', e => {
  const o = e.target.classList && e.target.classList.contains('overlay') ? e.target : null;
  if (o && o.dataset.backdrop === '1') o.classList.remove('on');
  const img = e.target.closest && e.target.closest('[data-lb]');
  if (img) M.lightbox(img.dataset.lb);
});
M.lightbox = src => {
  let lb = document.getElementById('lightbox');
  if (!lb) {
    lb = document.createElement('div'); lb.id = 'lightbox';
    lb.innerHTML = `<button class="btn" type="button">${M.icon('x')} إغلاق</button><img alt="">`;
    lb.addEventListener('click', () => lb.classList.remove('on'));
    document.body.appendChild(lb);
  }
  lb.querySelector('img').src = src; lb.classList.add('on');
};

/* ---------------- الصور ---------------- */
// تصغير صور الموبايل قبل الرفع (صور الكاميرا بتبقى 4-8 ميجا، والسيرفر كان بيرفضها بدون ما يقول)
M.compress = (file, max = 1600, q = 0.82) => new Promise(res => {
  if (!file || !/^image\//.test(file.type) || file.type === 'image/gif') return res(file);
  const img = new Image(), url = URL.createObjectURL(file);
  img.onload = () => {
    const s = Math.min(1, max / Math.max(img.width, img.height));
    if (s === 1 && file.size < 700 * 1024) { URL.revokeObjectURL(url); return res(file); }
    const c = document.createElement('canvas');
    c.width = Math.round(img.width * s); c.height = Math.round(img.height * s);
    c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
    c.toBlob(b => {
      URL.revokeObjectURL(url);
      res(b ? new File([b], (file.name || 'photo').replace(/\.\w+$/, '') + '.jpg', { type: 'image/jpeg' }) : file);
    }, 'image/jpeg', q);
  };
  img.onerror = () => { URL.revokeObjectURL(url); res(file); };
  img.src = url;
});
// اختيار صورة داخل نموذج: <label class="pick"> ... </label>
M.bindPick = (label, label2) => {
  const input = label.querySelector('input'), lbl = label.querySelector('.lbl');
  input.addEventListener('change', () => {
    const f = input.files[0]; if (!f) return;
    let img = label.querySelector('img');
    if (!img) { img = document.createElement('img'); label.prepend(img); }
    img.src = URL.createObjectURL(f); label.classList.add('has');
    lbl.textContent = 'تغيير الصورة';
  });
  label._reset = (src, text) => {
    input.value = ''; const img = label.querySelector('img'); if (img) img.remove();
    label.classList.remove('has'); lbl.textContent = text;
    if (src) { const i = document.createElement('img'); i.src = src; label.prepend(i); label.classList.add('has'); lbl.textContent = 'تغيير الصورة'; }
  };
};

/* ---------------- بيانات العميل (نفس الشكل في كل الشاشات) ---------------- */
const kv = (rows) => {
  const r = rows.filter(x => x[1] !== undefined && x[1] !== null && String(x[1]).trim() !== '' && String(x[1]) !== '0');
  return r.length ? `<dl class="kv">${r.map(x => `<dt>${x[0]}</dt><dd>${x[2] ? x[1] : M.esc(x[1])}</dd>`).join('')}</dl>` : '';
};
M.customerBody = (c, o = {}) => {
  const d = M.debt(c), inst = +c.installment || 0, delay = +c.delay_days || 0;
  const L = M.legal(c);
  let h = `<div class="stmt">
    <div class="stmt-row"><span>رصيد القرض</span><i></i><b>${M.money(d.loan)}</b></div>
    <div class="stmt-row"><span>فوائد وغرامات</span><i></i><b>${M.money(d.fees)}</b></div>
    <div class="stmt-total"><span>إجمالي المديونية</span><b>${M.money(d.total)}<small>ج.م</small></b></div>
    <div class="stmt-foot"><div>القسط<b>${M.money(inst)}</b></div><div>أيام التأخير<b class="${delay > 90 ? 'bad' : ''}">${M.num(delay)}</b></div></div></div>`;

  h += `<div class="legal ${L.hasVerdict ? 'verdict' : L.hasCase ? 'risk' : ''}">${M.icon('shield')}<div>${L.hasCase ? 'قضية رقم <b class="ltr num">' + M.esc(L.num) + '</b>' : 'لا توجد قضية'}${L.hasVerdict ? ' — حكم: <b>' + M.esc(L.st) + '</b>' : ''}</div></div>`;

  if (c.address || c.landmark) {
    const q = [c.address, c.governorate].filter(Boolean).join(' ');
    h += `<div class="block"><div class="block-t">${M.icon('pin')} العنوان</div><div class="block-b">${M.esc(c.address || '')}${c.landmark ? `<div class="muted small" style="margin-top:2px">علامة مميزة: ${M.esc(c.landmark)}</div>` : ''}</div>
      ${c.address ? `<a class="btn sm" style="margin-top:8px" target="_blank" rel="noopener" href="${M.mapsUrl(q)}">${M.icon('nav')} افتح في الخريطة</a>` : ''}</div>`;
  }
  if (c.guarantor_name || c.guarantor_phone) {
    h += `<div class="block"><div class="block-t">${M.icon('users')} الضامن${c.guarantor_relation ? ' · ' + M.esc(c.guarantor_relation) : ''}</div>
      <div class="block-b">${M.esc(c.guarantor_name || '—')}${c.guarantor_phone ? `<div class="row" style="margin-top:6px"><span class="ltr num">${M.esc(c.guarantor_phone)}</span>
        ${M.callBtn(c.guarantor_phone, { cls: '', sm: true, label: 'اتصال', name: c.guarantor_name })}<a class="btn sm wa" target="_blank" rel="noopener" href="${M.waUrl(c.guarantor_phone)}">${M.icon('chat')} واتساب</a></div>` : ''}</div></div>`;
  }
  if (c.activity_address) {
    h += `<div class="block"><div class="block-t">${M.icon('briefcase')} عنوان النشاط</div><div class="block-b">${M.esc(c.activity_address)}${c.activity_landmark ? `<div class="muted small">علامة مميزة: ${M.esc(c.activity_landmark)}</div>` : ''}</div></div>`;
  }
  if (c.nid) h += `<div class="block"><div class="block-t">${M.icon('card')} الرقم القومي</div><div class="block-b"><span class="ltr num">${M.esc(c.nid)}</span></div></div>`;

  if (c.id_front_image || c.id_back_image) {
    const th = (src, cap) => `<figure class="thumb" style="margin:0">${src ? `<img src="${M.esc(src)}" data-lb="${M.esc(src)}" alt="${cap}" loading="lazy">` : '<div class="none">لا توجد صورة</div>'}<div class="cap">${cap}</div></figure>`;
    h += `<div class="section-t">صور البطاقة</div><div class="thumbs">${th(c.id_front_image, 'وجه البطاقة')}${th(c.id_back_image, 'ظهر البطاقة')}</div>`;
  }

  const more = [
    kv([['مبلغ المنح', c.grant_amount ? M.money(c.grant_amount) : ''], ['الفائدة', c.interest ? M.money(c.interest) : ''], ['الغرامة', c.fine ? M.money(c.fine) : ''], ['تاريخ المنح', c.grant_date], ['تاريخ القسط المتأخر', c.late_installment_date], ['مدفوع', c.paid], ['تاريخ الدفع', c.paid_date], ['Broken', c.broken]]),
    kv([['رقم القرض', c.loan_number ? `<span class="ltr num">${M.esc(c.loan_number)}</span>` : '', 1], ['رقم العميل', c.client_number ? `<span class="ltr num">${M.esc(c.client_number)}</span>` : '', 1], ['الفرع', c.branch], ['المحافظة', c.governorate], ['Coll', c.coll], ['S.V', c.s_v], ['Portfolio', c.portfolio], ['مسؤول التمويل', c.finance_officer], ['Sep Owner', c.sep_owner], ['الفيدباك', c.feedback], ['تاريخ الإعدام', c.execution_date]]),
    kv([['بطاقة الضامن', c.guarantor_card ? `<span class="ltr num">${M.esc(c.guarantor_card)}</span>` : '', 1], ['عنوان الضامن', c.guarantor_address], ['علامة الضامن', c.guarantor_landmark]]),
    kv([['من شيت', c.sheet_name && c.sheet_name !== 'manual' ? c.sheet_name : ''], ['صاحب الشيت', c.owner_name]])
  ].filter(Boolean);
  if (more.length) h += `<details class="more"><summary>${M.icon('down')} باقي التفاصيل</summary><div class="block" style="margin-top:0">${more.join('<div style="height:10px"></div>')}</div></details>`;
  return h;
};
// آخر ملاحظة بشكل بارز + باقي السجل
M.notesBlock = dcr => {
  const n = M.notes(dcr); if (!n.length) return '';
  const last = n[n.length - 1], rest = n.slice(0, -1);
  return `<div class="note"><small>آخر ملاحظة</small>${M.esc(last)}${rest.length ? `<details style="margin-top:6px"><summary class="small muted" style="cursor:pointer">السجل السابق (${rest.length})</summary><ul style="margin:6px 0 0;padding-inline-start:18px" class="small">${rest.reverse().map(x => `<li>${M.esc(x)}</li>`).join('')}</ul></details>` : ''}</div>`;
};

/* ---------------- لوحة الشيت (رفع / تحميل) ---------------- */
M.sheetPanel = (el, onChange) => {
  el.innerHTML = `<div class="panel"><div class="panel-h">شيت العملاء</div><div class="panel-b">
    <div id="spInfo" class="hide"></div>
    <div id="spDrop" class="drop">${M.icon('upload')}<b>اضغط هنا لرفع الشيت (.xlsx)</b><span class="muted small">هيتقرا تلقائيًا وتقدر تشتغل عليه فورًا</span><input type="file" id="spFile" accept=".xlsx" class="hide"></div>
    <div id="spMsg" class="small" style="margin-top:12px" role="status"></div></div></div>`;
  const info = M.$('#spInfo', el), drop = M.$('#spDrop', el), file = M.$('#spFile', el), msg = M.$('#spMsg', el);
  const say = (t, type) => { msg.className = 'small alert ' + (type || 'info'); msg.style.display = t ? 'flex' : 'none'; msg.textContent = t || ''; };
  say('');
  let pendingReplace = false;

  function showDrop(isReplace) {
    pendingReplace = !!isReplace;
    info.classList.add('hide');
    drop.classList.remove('hide');
    drop.querySelector('b').textContent = isReplace ? 'اختر ملف الشيت الجديد (.xlsx)' : 'اضغط هنا لرفع الشيت (.xlsx)';
  }
  function showInfo(s) {
    pendingReplace = false;
    info.classList.remove('hide');
    drop.classList.add('hide');
    info.innerHTML = `<div class="row nowrap" style="margin-bottom:12px"><span class="tag ok">${M.icon('file')}</span><div class="grow"><b class="trunc" style="display:block">${M.esc(s.filename)}</b>
      <span class="muted small">${M.num(s.client_count)} عميل · اترفع ${M.dt(s.uploaded_at)}${s.last_download_at ? ' · آخر تحميل ' + M.dt(s.last_download_at) : ''}</span></div></div>
      <div class="row" style="flex-wrap:wrap;gap:8px">
        <button class="btn primary grow" id="spDown" type="button">${M.icon('download')} تحميل آخر شيت محدّث</button>
        <button class="btn grow" id="spRe" type="button">${M.icon('refresh')} استبدال الشيت</button>
      </div>
      <p class="muted small" style="margin-top:10px">الشيت المعروض فوق هو آخر شيت اترفّع. أي حالة أو ملاحظة بتسجلها بتتحفظ، وبتنزّل جوّه الملف لما تحمّله.</p>`;
    M.$('#spDown', el).onclick = e => M.busy(e.currentTarget, async () => {
      say('جاري تجهيز الملف...', 'info');
      try { await M.download('download_sheet'); say('تم التحميل ✓', 'ok'); load(); } catch (err) { say(err.message, 'bad'); }
    });
    M.$('#spRe', el).onclick = () => showDrop(true);
  }

  async function load() {
    const j = await M.get('my_sheet_info');
    if (!j.success) return null;
    if (j.has_sheet && j.sheet) showInfo(j.sheet);
    else showDrop(false);
    return j;
  }

  async function upload(f) {
    if (!f) return;
    if (!/\.xlsx$/i.test(f.name)) return say('الملف لازم يكون بصيغة .xlsx', 'bad');
    if (f.size > 20 * 1024 * 1024) return say('حجم الملف أكبر من 20 ميجا', 'bad');

    let cycle = null;
    if (['collector', 'data_entry'].includes(M.user && M.user.role)) {
      const cycleResult = await M.get('my_collection_cycle');
      if (!cycleResult.success) return say(cycleResult.message || 'تعذر التحقق من دورة التحصيل', 'bad');
      cycle = cycleResult.cycle || null;
      M.activeCollectionCycle = cycle;
    }
    if (cycle && (['submitted', 'approved'].includes(cycle.assignment_status) || cycle.status === 'review')) {
      return say('تم إرسال ملف هذه الدورة للمراجعة؛ لا يمكن رفع ملف جديد حتى تعيد الإدارة فتح الإسناد.', 'bad');
    }
    let deleteOld = 0;
    if (pendingReplace && !cycle) {
      const choice = await new Promise(resolve => {
        const id = 'spDelAsk';
        let o = document.getElementById(id);
        if (o) o.remove();
        o = document.createElement('div');
        o.id = id;
        o.className = 'overlay on';
        o.innerHTML = `<div class="sheet" role="dialog" aria-modal="true">
          <div class="sheet-h"><h3>استبدال الشيت</h3><button class="btn quiet icon-btn" type="button" data-a="cancel" aria-label="إغلاق">${M.icon('x')}</button></div>
          <div class="sheet-b">
            <p style="margin-bottom:10px">هترفع شيت جديد. عايز تعمل إيه في <b>العملاء القدامى</b> اللي عندك دلوقتي؟</p>
            <div class="note"><small>مهم</small>حذف العملاء القدامى بيمسح بيانات العملاء المرتبطين بحسابك من النظام (مش بيمسح سجل المكالمات والزيارات القديمة).</div>
          </div>
          <div class="sheet-f" style="flex-wrap:wrap;gap:8px">
            <button class="btn" type="button" data-a="cancel">إلغاء</button>
            <button class="btn" type="button" data-a="keep">استبدال بدون حذف</button>
            <button class="btn danger" type="button" data-a="delete">حذف القدامى ورفع الجديد</button>
          </div>
        </div>`;
        document.body.appendChild(o);
        o.addEventListener('click', e => {
          const b = e.target.closest('[data-a]');
          if (!b) return;
          const a = b.dataset.a;
          o.remove();
          if (a === 'cancel') resolve(null);
          else if (a === 'delete') resolve(1);
          else resolve(0);
        });
      });
      if (choice === null) { file.value = ''; return; }
      deleteOld = choice;
    }

    say('جاري الرفع وقراءة العملاء... (ممكن ياخد نص دقيقة)', 'info');
    const fd = new FormData();
    fd.append('sheet', f);
    fd.append('delete_old', String(deleteOld));
    if (cycle) fd.append('cycle_id', String(cycle.id));
    const j = await M.api('?action=upload_sheet', { method: 'POST', body: fd });
    file.value = '';
    if (j.success) {
      say((j.message || '').replace('✅ ', ''), j.failed ? 'warn' : 'ok');
      await load();
      onChange && onChange();
    } else say(j.message || 'تعذر رفع الملف', 'bad');
  }

  drop.onclick = e => { if (e.target.closest('input')) return; file.click(); };
  drop.ondragover = e => { e.preventDefault(); drop.classList.add('drag'); };
  drop.ondragleave = () => drop.classList.remove('drag');
  drop.ondrop = e => { e.preventDefault(); drop.classList.remove('drag'); upload(e.dataTransfer.files[0]); };
  file.onchange = () => upload(file.files[0]);
  load();
  return { reload: load };
};

M.collectionCyclePanel = el => {
  if (!el || !['collector', 'data_entry'].includes(M.user && M.user.role)) return;
  let cycle = null;
  const labels = { draft: 'مسودة', active: 'نشطة', review: 'قيد المراجعة', closed: 'مغلقة', archived: 'مؤرشفة' };
  const assignmentLabels = { pending: 'بانتظار بدء العمل', working: 'قيد العمل', submitted: 'تم الإرسال للمراجعة', approved: 'تم الاعتماد' };
  const load = async () => {
    const result = await M.get('my_collection_cycle');
    if (!result.success) {
      M.activeCollectionCycle = null;
      el.innerHTML = `<div class="alert bad">${M.esc(result.message || 'تعذر تحميل دورة التحصيل')}</div>`;
      return;
    }
    cycle = result.cycle || null;
    M.activeCollectionCycle = cycle;
    if (!cycle) {
      el.innerHTML = '';
      return;
    }
    const canSubmit = Number(cycle.client_count) > 0 && !['submitted', 'approved'].includes(cycle.assignment_status);
    el.innerHTML = `<div class="panel cycle-panel"><div class="panel-h">${M.icon('briefcase')} دورة التحصيل النشطة</div>
      <div class="panel-b"><div class="row" style="justify-content:space-between;align-items:flex-start">
        <div class="grow"><b>${M.esc(cycle.name)}</b><div class="muted small">شهر ${M.esc(cycle.month_key)} · ${M.esc(labels[cycle.status] || cycle.status)}</div></div>
        <span class="tag ${cycle.assignment_status === 'approved' ? 'ok' : cycle.assignment_status === 'submitted' ? 'warn' : 'brand'}">${M.esc(assignmentLabels[cycle.assignment_status] || cycle.assignment_status)}</span>
      </div><div class="muted small" style="margin-top:8px">${M.num(cycle.client_count)} عميل مرتبط بالدورة</div>
      <div class="item" style="margin-top:12px;border:1px solid var(--line,#E7ECF0);border-radius:12px;padding:12px">
        <div class="grow"><div class="muted small">إجمالي التحصيل الذي سجله المشرف لك في هذه الدورة</div><b class="num" style="font-size:22px;color:var(--brass)">${M.money(cycle.credited_total)} ج.م</b></div>
        <span aria-hidden="true">${M.icon('chart')}</span>
      </div>
      ${canSubmit ? `<button class="btn primary block" type="button" data-submit-cycle="${Number(cycle.id)}" style="margin-top:10px">${M.icon('send')} إرسال الملف للمراجعة</button>` : ''}</div></div>`;
  };
  el.addEventListener('click', async event => {
    const button = event.target.closest('[data-submit-cycle]');
    if (!button) return;
    const result = await M.post('submit_collection_assignment', { cycle_id: Number(button.dataset.submitCycle) });
    if (!result.success) return M.err(result.message || 'تعذر إرسال الملف');
    M.toast(result.message || 'تم إرسال الملف للمراجعة');
    await load();
  });
  load();
  return { reload: load };
};


/* ---------------- الهيدر المشترك ---------------- */
M.appbar = (o = {}) => {
  const u = M.user || {};
  const calendarLink = `<button class="btn icon-btn" type="button" title="التقويم" aria-label="التقويم" onclick="M.openCalendarModal()">${M.icon('calendar')}</button>`;
  return `<header class="appbar"><div class="appbar-in">
    <img class="mark brand-mark" src="assets/brand-symbol.png" alt="شعار شركة الموارد">
    <div class="brand-t grow trunc">${M.esc(o.title || u.full_name || '')}<small>${M.esc(o.sub || 'شركة الموارد')}</small></div>
    ${o.actions || ''}
    ${calendarLink}
    <button class="btn icon-btn" type="button" title="إعدادات الاتصال" aria-label="إعدادات الاتصال" onclick="M.openCallSettings()">${M.icon('settings')}</button>
    <button class="btn icon-btn" type="button" title="تسجيل الخروج" aria-label="تسجيل الخروج" onclick="M.logout()">${M.icon('logout')}</button>
  </div></header>`;
};

M.openCalendarModal = async () => {
  let overlay = document.getElementById('calendarModal');
  if (!overlay) {
    overlay = document.createElement('div');
    overlay.id = 'calendarModal';
    overlay.className = 'calendar-modal-overlay';
    overlay.innerHTML = `<section class="calendar-modal" role="dialog" aria-modal="true" aria-labelledby="calendarModalTitle">
      <header class="calendar-modal-head"><h2 id="calendarModalTitle">${M.icon('calendar')} التقويم</h2><button type="button" class="calendar-modal-close" aria-label="إغلاق">${M.icon('x')}</button></header>
      <div class="calendar-modal-body">
        <div class="calendar-modal-month"><button type="button" data-month-step="-1" aria-label="الشهر السابق">‹</button><b></b><button type="button" data-month-step="1" aria-label="الشهر التالي">‹</button></div>
        <div class="calendar-modal-weekdays">${['السبت','الأحد','الاثنين','الثلاثاء','الأربعاء','الخميس','الجمعة'].map(day => `<span>${day}</span>`).join('')}</div>
        <div class="calendar-modal-grid" role="grid"></div>
        <div class="calendar-modal-day"><div class="calendar-modal-day-head"><b></b><button type="button" class="btn primary sm" data-new-event>${M.icon('plus')} موعد جديد</button></div><div class="calendar-modal-events"></div></div>
        <form class="calendar-modal-form hide">
          <label class="field"><span>عنوان الموعد</span><input class="input" name="title" maxlength="200" required></label>
          <div class="grid2"><label class="field"><span>النوع</span><select class="select" name="event_type"><option value="meeting">اجتماع</option><option value="call">مكالمة</option><option value="visit">زيارة</option><option value="reminder">تذكير</option><option value="other">أخرى</option></select></label><label class="field"><span>التاريخ والوقت</span><input class="input" name="start_at" type="datetime-local" required></label></div>
          <label class="field"><span>ملاحظات</span><textarea class="textarea" name="note" maxlength="1000" rows="2"></textarea></label>
          <div class="calendar-modal-form-actions"><button class="btn sm" type="button" data-cancel-event>إلغاء</button><button class="btn primary sm" type="submit">حفظ</button></div>
        </form>
      </div>
    </section>`;
    document.body.appendChild(overlay);
    const state = { month: new Date(new Date().getFullYear(), new Date().getMonth(), 1), selected: M.today(), events: [] };
    const $ = selector => overlay.querySelector(selector);
    const keyFor = date => `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}-${String(date.getDate()).padStart(2, '0')}`;
    const titleFor = date => date.toLocaleDateString('ar-EG', { month: 'long', year: 'numeric' });
    const selectedTitle = () => new Date(state.selected + 'T00:00:00').toLocaleDateString('ar-EG', { day: 'numeric', month: 'long', year: 'numeric' });
    const renderEvents = () => {
      const list = state.events.filter(event => String(event.start_at || '').slice(0, 10) === state.selected);
      $('.calendar-modal-day-head>b').textContent = selectedTitle();
      $('.calendar-modal-events').innerHTML = list.length ? list.map(event => `<article class="calendar-modal-event">
        <time>${Number(event.all_day) ? 'طوال اليوم' : M.esc(String(event.start_at || '').slice(11, 16))}</time>
        <div class="grow"><b>${M.esc(event.title)}</b>${event.note ? `<small>${M.esc(event.note)}</small>` : ''}</div>
        <button class="btn quiet icon-btn" type="button" data-finish="${Number(event.id)}" aria-label="${event.status === 'done' ? 'إعادة فتح' : 'إنهاء'}">${M.icon(event.status === 'done' ? 'refresh' : 'check')}</button>
        <button class="btn quiet icon-btn" type="button" data-remove="${Number(event.id)}" aria-label="حذف">${M.icon('trash')}</button>
      </article>`).join('') : '<p class="calendar-modal-empty">مفيش مواعيد في اليوم ده</p>';
      const currentMonth = `${state.month.getFullYear()}-${String(state.month.getMonth() + 1).padStart(2, '0')}`;
      const first = new Date(state.month.getFullYear(), state.month.getMonth(), 1);
      const offset = (first.getDay() + 1) % 7;
      const days = new Date(state.month.getFullYear(), state.month.getMonth() + 1, 0).getDate();
      const cells = Array.from({ length: 42 }, (_, index) => {
        const day = index - offset + 1;
        if (day < 1 || day > days) return '<span class="calendar-modal-blank" aria-hidden="true"></span>';
        const date = new Date(state.month.getFullYear(), state.month.getMonth(), day);
        const key = keyFor(date);
        const count = state.events.filter(item => String(item.start_at || '').slice(0, 10) === key).length;
        return `<button type="button" class="${key === state.selected ? 'selected ' : ''}${key === M.today() ? 'today' : ''}" data-date="${key}" aria-pressed="${key === state.selected}">${day}${count ? `<i>${count > 9 ? '9+' : count}</i>` : ''}</button>`;
      });
      $('.calendar-modal-month>b').textContent = titleFor(state.month);
      $('.calendar-modal-grid').innerHTML = cells.join('');
      $('.calendar-modal-form').classList.add('hide');
      $('.calendar-modal-day').classList.remove('hide');
    };
    const loadEvents = async () => {
      const month = `${state.month.getFullYear()}-${String(state.month.getMonth() + 1).padStart(2, '0')}`;
      const result = await M.get('get_calendar_events', { month });
      if (!result.success) { M.err(result.message || 'تعذر تحميل التقويم'); return; }
      state.events = result.events || [];
      if (!state.selected.startsWith(month)) state.selected = keyFor(state.month);
      renderEvents();
    };
    overlay.addEventListener('click', async event => {
      if (event.target === overlay || event.target.closest('.calendar-modal-close')) { M.close('calendarModal'); return; }
      const monthButton = event.target.closest('[data-month-step]');
      if (monthButton) { state.month.setMonth(state.month.getMonth() + Number(monthButton.dataset.monthStep)); await loadEvents(); return; }
      const dayButton = event.target.closest('[data-date]');
      if (dayButton) { state.selected = dayButton.dataset.date; renderEvents(); return; }
      if (event.target.closest('[data-new-event]')) {
        const form = $('.calendar-modal-form');
        form.reset();
        form.elements.start_at.value = `${state.selected}T09:00`;
        $('.calendar-modal-day').classList.add('hide');
        form.classList.remove('hide');
        form.elements.title.focus();
        return;
      }
      if (event.target.closest('[data-cancel-event]')) { renderEvents(); return; }
      const finish = event.target.closest('[data-finish]');
      if (finish) {
        const result = await M.post('complete_calendar_event', { id: Number(finish.dataset.finish) });
        if (!result.success) return M.err(result.message || 'تعذر تحديث الموعد');
        await loadEvents();
        return;
      }
      const remove = event.target.closest('[data-remove]');
      if (remove && await M.confirm('حذف هذا الموعد؟', { danger: true, ok: 'حذف' })) {
        const result = await M.post('delete_calendar_event', { id: Number(remove.dataset.remove) });
        if (!result.success) return M.err(result.message || 'تعذر حذف الموعد');
        await loadEvents();
      }
    });
    overlay.addEventListener('keydown', event => {
      if (event.key === 'Escape') M.close('calendarModal');
    });
    overlay.tabIndex = -1;
    $('.calendar-modal-form').addEventListener('submit', async event => {
      event.preventDefault();
      const form = event.currentTarget;
      const data = new FormData(form);
      const result = await M.post('save_calendar_event', {
        title: String(data.get('title') || '').trim(),
        event_type: data.get('event_type'),
        start_at: data.get('start_at'),
        note: String(data.get('note') || '').trim()
      });
      if (!result.success) return M.err(result.message || 'تعذر حفظ الموعد');
      state.selected = String(data.get('start_at')).slice(0, 10);
      const date = new Date(state.selected + 'T00:00:00');
      state.month = new Date(date.getFullYear(), date.getMonth(), 1);
      M.toast(result.message || 'تم حفظ الموعد');
      await loadEvents();
    });
    overlay._loadEvents = loadEvents;
  }
  M.open('calendarModal');
  overlay.focus();
  await overlay._loadEvents();
};

// تبويبات: عناصر بـ data-tab، ومحتوى بـ id = pane-<name>
M.tabs = (root, onShow) => {
  const btns = M.$$('[data-tab]', root);
  const show = name => {
    btns.forEach(b => b.classList.toggle('on', b.dataset.tab === name));
    M.$$('.tabpane').forEach(p => p.classList.toggle('on', p.id === 'pane-' + name));
    try { sessionStorage.setItem('tab:' + location.pathname, name); } catch (e) {}
    onShow && onShow(name);
  };
  btns.forEach(b => b.addEventListener('click', () => show(b.dataset.tab)));
  let first = btns[0] && btns[0].dataset.tab;
  try { const s = sessionStorage.getItem('tab:' + location.pathname); if (s && btns.some(b => b.dataset.tab === s)) first = s; } catch (e) {}
  if (first) show(first);
  return show;
};

/* ---------------- إشعارات داخلية (صوت مستمر حتى الاطلاع) ---------------- */
M._notifPlaying = false;
M._notifAudioCtx = null;
M._notifOsc = null;
M._notifGain = null;
M._notifInterval = null;
M._notifCurrentId = null;

M._startNotifSound = () => {
  if (M._notifPlaying) return;
  M._notifPlaying = true;
  try {
    const Ctx = window.AudioContext || window.webkitAudioContext;
    if (!Ctx) return;
    if (!M._notifAudioCtx) M._notifAudioCtx = new Ctx();
    const ctx = M._notifAudioCtx;
    if (ctx.state === 'suspended') ctx.resume();
    const beep = () => {
      if (!M._notifPlaying) return;
      try {
        const o = ctx.createOscillator();
        const g = ctx.createGain();
        o.type = 'sine';
        o.frequency.value = 880;
        g.gain.setValueAtTime(0.0001, ctx.currentTime);
        g.gain.exponentialRampToValueAtTime(0.25, ctx.currentTime + 0.02);
        g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.35);
        o.connect(g); g.connect(ctx.destination);
        o.start(); o.stop(ctx.currentTime + 0.4);
      } catch (e) {}
    };
    beep();
    M._notifInterval = setInterval(beep, 1200);
  } catch (e) {}
};

M._stopNotifSound = () => {
  M._notifPlaying = false;
  if (M._notifInterval) { clearInterval(M._notifInterval); M._notifInterval = null; }
};

M._showNotifOverlay = (n) => {
  let ov = document.getElementById('sysNotif');
  if (!ov) {
    ov = document.createElement('div');
    ov.id = 'sysNotif';
    ov.className = 'sys-notif';
    document.body.appendChild(ov);
  }
  M._notifCurrentId = n.id;
  ov.innerHTML = `<div class="sys-notif-card" role="alertdialog" aria-modal="true">
    <div class="sys-notif-pulse"></div>
    <div class="sys-notif-icon">${M.icon('bell')}</div>
    <h3>${M.esc(n.title)}</h3>
    <p>${M.esc(n.body)}</p>
    <div class="muted small" style="margin-bottom:14px">من: ${M.esc(n.from_name || 'الإدارة')} · ${M.esc(M.dt(n.created_at))}</div>
    <button type="button" class="btn primary block" id="sysNotifAck">${M.icon('check')} تم الاطلاع</button>
  </div>`;
  ov.style.display = 'flex';
  M._startNotifSound();
  const btn = document.getElementById('sysNotifAck');
  btn.onclick = async () => {
    btn.disabled = true;
    try {
      await M.post('ack_notification', { id: n.id });
    } catch (e) {}
    M._stopNotifSound();
    ov.style.display = 'none';
    M._notifCurrentId = null;
    // check if more waiting
    setTimeout(() => M._pollNotifications(true), 400);
  };
};

M._pollNotifications = async (force) => {
  if (!M.token || !M.user) return;
  try {
    const j = await M.get('my_notifications');
    if (!j.success) return;
    const list = j.notifications || [];
    if (!list.length) {
      if (M._notifCurrentId) {
        M._stopNotifSound();
        const ov = document.getElementById('sysNotif');
        if (ov) ov.style.display = 'none';
        M._notifCurrentId = null;
      }
      return;
    }
    // show first unread; keep sound until ack
    const n = list[0];
    if (M._notifCurrentId !== n.id || force) {
      M._showNotifOverlay(n);
    } else if (!M._notifPlaying) {
      M._startNotifSound();
    }
  } catch (e) {}
};

// start polling after auth is available
(function startNotifPoll() {
  const boot = () => {
    if (!M.token || !M.user) return;
    M._pollNotifications();
    setInterval(() => M._pollNotifications(), 8000);
  };
  if (M.token && M.user) boot();
  else {
    // guard may set user later; poll after short delay
    setTimeout(boot, 600);
    setTimeout(boot, 2000);
  }
  // resume sound on user interaction (browser autoplay policy)
  const unlock = () => {
    if (M._notifAudioCtx && M._notifAudioCtx.state === 'suspended') M._notifAudioCtx.resume();
    if (M._notifCurrentId && !M._notifPlaying) M._startNotifSound();
  };
  document.addEventListener('click', unlock, { once: false });
  document.addEventListener('touchstart', unlock, { once: false });
})();



/* ---------------- PWA Service Worker ---------------- */
M.registerSW = () => {
  if (!('serviceWorker' in navigator)) return;
  if (M.ENV === 'local') {
    navigator.serviceWorker.getRegistrations()
      .then(registrations => Promise.all(registrations.map(registration => registration.unregister())))
      .catch(error => console.warn('تعذر إيقاف Service Worker في بيئة التطوير المحلية', error));
    if ('caches' in window) {
      caches.keys()
        .then(keys => Promise.all(keys.filter(key => key.startsWith('mawared-')).map(key => caches.delete(key))))
        .catch(error => console.warn('تعذر تنظيف cache في بيئة التطوير المحلية', error));
    }
    return;
  }
  const swUrl = 'sw.js';
  window.addEventListener('load', () => {
    navigator.serviceWorker.register(swUrl).then(reg => {
      reg.addEventListener('updatefound', () => {
        const w = reg.installing;
        if (!w) return;
        w.addEventListener('statechange', () => {
          if (w.state === 'installed' && navigator.serviceWorker.controller) {
            // update available — soft prompt
            try {
              if (typeof M.toast === 'function') {
                M.toast('في تحديث جديد للتطبيق', {
                  ms: 8000,
                  action: {
                    label: 'تحديث',
                    fn: () => {
                      if (w.state === 'installed') w.postMessage && w.postMessage('SKIP_WAITING');
                      // tell waiting worker
                      if (reg.waiting) reg.waiting.postMessage('SKIP_WAITING');
                      location.reload();
                    }
                  }
                });
              }
            } catch (e) {}
          }
        });
      });
    }).catch(() => {});
  });
};
M.registerSW();

/* تثبيت التطبيق (Add to Home Screen) */
M._deferredInstall = null;
window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  M._deferredInstall = e;
  try {
    if (typeof M.toast === 'function' && !sessionStorage.getItem('pwa_hint')) {
      sessionStorage.setItem('pwa_hint', '1');
      M.toast('تقدر تثبّت التطبيق على الشاشة الرئيسية', {
        ms: 7000,
        action: {
          label: 'تثبيت',
          fn: () => M.promptInstall()
        }
      });
    }
  } catch (err) {}
});
M.promptInstall = async () => {
  if (!M._deferredInstall) {
    if (typeof M.toast === 'function') M.toast('افتح من المتصفح (Chrome/Edge) أو من قائمة المشاركة → إضافة للشاشة الرئيسية');
    return false;
  }
  M._deferredInstall.prompt();
  const choice = await M._deferredInstall.userChoice;
  M._deferredInstall = null;
  return choice && choice.outcome === 'accepted';
};



/* ---------------- أوفلاين: طابور حفظ الزيارات/المكالمات ---------------- */
M._offlineQ = [];
try { M._offlineQ = JSON.parse(localStorage.getItem('mawared_offline_q') || '[]'); } catch (e) { M._offlineQ = []; }
M._saveQ = () => { try { localStorage.setItem('mawared_offline_q', JSON.stringify(M._offlineQ)); } catch (e) {} };
M.queueOffline = (action, body, label) => {
  M._offlineQ.push({ id: Date.now() + Math.random(), action, body, label: label || action, at: new Date().toISOString() });
  M._saveQ();
  M.toast('اتحفظ محليًا — هيتبعت لما النت يرجع', { type: '', ms: 4000 });
};
M.flushOffline = async () => {
  if (!M._offlineQ.length || !navigator.onLine) return;
  const left = [];
  for (const item of M._offlineQ) {
    try {
      const j = await M.post(item.action, item.body);
      if (!j.success) left.push(item);
    } catch (e) { left.push(item); }
  }
  const sent = M._offlineQ.length - left.length;
  M._offlineQ = left;
  M._saveQ();
  if (sent > 0) M.toast(`اتزامنت ${sent} عملية محفوظة أوفلاين`);
};
window.addEventListener('online', () => M.flushOffline());
setInterval(() => M.flushOffline(), 20000);
// flush once after load
setTimeout(() => M.flushOffline(), 2500);

/* post with offline fallback for mark_visit / update_customer */
M.postOrQueue = async (action, body, label) => {
  try {
    const j = await M.post(action, body);
    if (j.network) {
      M.queueOffline(action, body, label);
      return { success: true, offline: true, message: 'اتحفظ أوفلاين' };
    }
    return j;
  } catch (e) {
    M.queueOffline(action, body, label);
    return { success: true, offline: true, message: 'اتحفظ أوفلاين' };
  }
};

/* ---------------- الهدف اليومي + مهامي ---------------- */
M.renderDailyTarget = async (el) => {
  if (!el) return;
  try {
    const j = await M.get('my_daily_target');
    const p = (j && j.progress) || {};
    const has = j && j.success && j.target && ((+p.calls_target) > 0 || (+p.visits_target) > 0);
    if (!has) {
      el.innerHTML = '';
      el.classList.add('hide');
      return;
    }
    el.classList.remove('hide');
    const cPct = p.calls_target ? Math.min(100, Math.round(100 * (+p.calls_done) / (+p.calls_target))) : 0;
    const vPct = p.visits_target ? Math.min(100, Math.round(100 * (+p.visits_done) / (+p.visits_target))) : 0;
    el.innerHTML = `<div class="panel" style="margin-bottom:12px"><div class="panel-b" style="padding:12px 14px">
      <div class="row nowrap" style="margin-bottom:8px"><b>هدف اليوم</b><span class="muted small ltr">${M.esc(j.date || '')}</span></div>
      ${+p.calls_target ? `<div class="muted small">مكالمات: <b class="ltr num">${M.num(p.calls_done)} / ${M.num(p.calls_target)}</b></div>
        <div style="height:6px;background:#E7ECF0;border-radius:99px;margin:4px 0 8px;overflow:hidden"><div style="height:100%;width:${cPct}%;background:var(--brand,#0B4A63)"></div></div>` : ''}
      ${+p.visits_target ? `<div class="muted small">زيارات: <b class="ltr num">${M.num(p.visits_done)} / ${M.num(p.visits_target)}</b></div>
        <div style="height:6px;background:#E7ECF0;border-radius:99px;margin:4px 0 0;overflow:hidden"><div style="height:100%;width:${vPct}%;background:#0B7A4B"></div></div>` : ''}
    </div></div>`;
  } catch (e) { try { el.innerHTML = ''; el.classList.add('hide'); } catch (x) {} }
};

M.renderMyTasks = async (el) => {
  if (!el) return;
  try {
    const j = await M.get('my_tasks', { status: 'open' });
    if (!j || !j.success) { el.innerHTML = ''; el.classList.add('hide'); return; }
    const tasks = j.tasks || [];
    if (!tasks.length) { el.innerHTML = ''; el.classList.add('hide'); return; }
    el.classList.remove('hide');
    el.innerHTML = `<div class="panel" style="margin-bottom:12px"><div class="panel-h">مهامي (${tasks.length})</div><div class="panel-b" style="padding:0">
      <div class="list">${tasks.map(t => `
        <div class="item" data-task="${t.id}">
          <div class="grow"><div class="item-t">${M.esc(t.title)}</div>
            <div class="item-s muted small">${t.due_date ? 'استحقاق ' + M.dmy(t.due_date) : 'بدون تاريخ'}${t.from_name ? ' · من ' + M.esc(t.from_name) : ''}</div>
            ${t.body ? `<div class="muted small" style="margin-top:2px">${M.esc(t.body)}</div>` : ''}
          </div>
          <button class="btn sm primary" type="button" data-done-task="${t.id}">تم</button>
        </div>`).join('')}</div></div></div>`;
    el.onclick = async e => {
      const b = e.target.closest('[data-done-task]'); if (!b) return;
      const j2 = await M.post('complete_task', { id: +b.dataset.doneTask });
      if (j2.success) { M.toast('تم'); M.renderMyTasks(el); } else M.err(j2.message);
    };
  } catch (e) { try { el.innerHTML = ''; el.classList.add('hide'); } catch (x) {} }
};

/** تحميل الهدف + المهام معًا (يُستدعى من كل صفحات الشغل) */
M.loadWorkPanel = (targetEl, tasksEl) => {
  if (targetEl) M.renderDailyTarget(targetEl);
  if (tasksEl) M.renderMyTasks(tasksEl);
};

/* ---------------- تذكيرات العملاء ---------------- */
M._pollReminders = async () => {
  if (!M.token || !M.user) return;
  try {
    const j = await M.get('my_reminders', { due: 1 });
    if (!j.success || !(j.reminders||[]).length) return;
    const r = j.reminders[0];
    // reuse notif overlay style if free
    let ov = document.getElementById('sysRemind');
    if (!ov) {
      ov = document.createElement('div');
      ov.id = 'sysRemind';
      ov.className = 'sys-notif';
      document.body.appendChild(ov);
    }
    if (ov.dataset.rid == r.id && ov.style.display === 'flex') return;
    ov.dataset.rid = r.id;
    ov.innerHTML = `<div class="sys-notif-card" role="alertdialog">
      <div class="sys-notif-icon">${M.icon('bell')}</div>
      <h3>تذكير: ${M.esc(r.client_name || 'عميل')}</h3>
      <p>${M.esc(r.note || 'ميعاد متابعة العميل')}</p>
      <div class="muted small" style="margin-bottom:12px">${M.esc(M.dt(r.remind_at))}${r.client_phone ? ' · ' + M.esc(r.client_phone) : ''}</div>
      <button type="button" class="btn primary block" id="sysRemindAck">تم — فهمت</button>
    </div>`;
    ov.style.display = 'flex';
    document.getElementById('sysRemindAck').onclick = async () => {
      await M.post('ack_reminder', { id: r.id });
      ov.style.display = 'none';
      setTimeout(() => M._pollReminders(), 500);
    };
  } catch (e) {}
};
setInterval(() => M._pollReminders(), 30000);
setTimeout(() => M._pollReminders(), 3000);


})();
