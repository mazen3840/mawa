(() => {
  const pageContent = document.getElementById('pageContent');
  if (!pageContent) return;
  const markup = pageContent.innerHTML;
  setupShell('center');
  document.getElementById('pageTitle').textContent = 'مركز عمليات التحصيل';
  document.getElementById('page').innerHTML = markup;

  const PAGE_SIZE = 20;
  const role = USER().role;
  const page = { offset: 0, total: 0, requestId: 0, timer: null };
  const elements = {
    status: document.getElementById('centerStatus'),
    kpis: document.getElementById('kpis'),
    rows: document.getElementById('rows'),
    tasks: document.getElementById('tasks'),
    payments: document.getElementById('payments'),
    activity: document.getElementById('recentActivity'),
    search: document.getElementById('queueSearch'),
    stage: document.getElementById('stageFilter'),
    delay: document.getElementById('delayFilter'),
    summary: document.getElementById('queueSummary'),
    pageInfo: document.getElementById('pageInfo'),
    previous: document.getElementById('previousPage'),
    next: document.getElementById('nextPage'),
    updated: document.getElementById('lastUpdated'),
  };

  const stageNames = {
    new: 'جديد',
    contacted: 'تم التواصل',
    visited: 'تمت الزيارة',
    promise: 'تعهد بالسداد',
    paid: 'تم التحصيل',
    partial: 'تحصيل جزئي',
    closed: 'مغلق',
  };

  const allowedNav = {
    center: true,
    collector: role === 'collector',
    calls: true,
    operations: ['admin', 'super_admin'].includes(role),
    admin: role === 'admin',
    data: ['admin', 'super_admin', 'data_entry'].includes(role),
    super: role === 'super_admin',
  };
  for (const [key, allowed] of Object.entries(allowedNav)) {
    if (!allowed) document.querySelector(`[data-nav="${key}"]`)?.remove();
  }
  document.querySelectorAll('.navtitle').forEach(title => {
    if (!title.nextElementSibling || title.nextElementSibling.classList.contains('navtitle')) title.remove();
  });

  if (['admin', 'super_admin'].includes(role)) {
    document.getElementById('primaryAction').href = 'operations.html';
    document.getElementById('primaryAction').textContent = 'إدارة دورات التحصيل';
    document.getElementById('secondaryAction').href = role === 'super_admin' ? 'superadmin.html' : 'admin.html';
    document.getElementById('secondaryAction').textContent = role === 'super_admin' ? 'الإدارة العليا' : 'إدارة الفريق';
  } else if (role === 'data_entry') {
    document.getElementById('primaryAction').href = 'dataentry.html';
    document.getElementById('primaryAction').textContent = 'فتح إدخال البيانات';
    document.getElementById('secondaryAction').href = 'my_calls.html';
    document.getElementById('secondaryAction').textContent = 'متابعة المكالمات';
  } else {
    document.getElementById('primaryAction').href = 'collector.html';
    document.getElementById('primaryAction').textContent = 'فتح مساحة المحصل';
    document.getElementById('secondaryAction').href = 'my_calls.html';
    document.getElementById('secondaryAction').textContent = 'متابعة المكالمات';
  }

  function showError(error) {
    elements.status.textContent = error.message || 'تعذر تحميل بيانات المركز';
    elements.status.classList.add('error');
    toast(elements.status.textContent);
  }

  function renderKpis(data) {
    const stats = data.stats || {};
    const cards = [
      { label: 'إجمالي الحالات', value: num(stats.total), help: 'ضمن نطاق صلاحيتك' },
      { label: 'إجمالي المديونية', value: money(stats.exposure), help: 'الرصيد القائم للحالات' },
      { label: 'التحصيل المعتمد', value: money(data.payments?.collected), help: 'إجمالي التحصيلات المعتمدة' },
      { label: 'تحصيلات للمراجعة', value: num(data.pending_review), help: 'تحتاج قرار الإدارة' },
      { label: 'متابعات متأخرة', value: num(stats.due_actions), help: 'مهام مفتوحة تجاوزت موعدها' },
      { label: 'مكالمات اليوم', value: num(data.calls_today), help: 'مسجلة من الموظفين' },
      { label: 'زيارات اليوم', value: num(data.visits_today), help: 'زيارات منفذة اليوم' },
    ];
    elements.kpis.innerHTML = cards.map(card => `
      <article class="center-kpi">
        <span>${esc(card.label)}</span>
        <strong>${esc(card.value)}</strong>
        <small>${esc(card.help)}</small>
      </article>`).join('');
  }

  function renderStages(stages) {
    const selected = elements.stage.value;
    const values = (stages || []).map(item => item.collection_stage).filter(Boolean);
    const unique = [...new Set(values)].sort((a, b) => String(a).localeCompare(String(b)));
    elements.stage.innerHTML = '<option value="">كل المراحل</option>' + unique.map(value =>
      `<option value="${esc(value)}">${esc(stageNames[value] || value)}</option>`
    ).join('');
    if (unique.includes(selected)) elements.stage.value = selected;
  }

  function renderQueue(data) {
    const clients = data.queue || [];
    page.total = Number(data.queue_total || 0);
    elements.summary.textContent = `عرض ${num(clients.length)} من ${num(page.total)} حالة مطابقة للفلاتر.`;
    elements.rows.innerHTML = clients.map(client => {
      const balance = Number(client.loan_balance || 0) + Number(client.interest_fine_balance || 0);
      const delay = Number(client.delay_days || 0);
      const delayClass = delay >= 30 ? 'bad' : delay > 0 ? 'warn' : 'ok';
      const stage = client.collection_stage || 'new';
      return `<tr>
        <td><b>${esc(client.name || '—')}</b><small class="center-phone">${esc(client.phone || '—')}</small></td>
        <td>${pill(`${num(delay)} يوم`, delayClass)}</td>
        <td>${money(balance)}</td>
        <td>${pill(stageNames[stage] || stage)}</td>
        <td><button class="btn sm" type="button" data-open-client="${Number(client.id)}">فتح الملف</button></td>
      </tr>`;
    }).join('') || '<tr><td colspan="5" class="empty">لا توجد حالات تطابق البحث والفلاتر.</td></tr>';

    const first = page.total ? page.offset + 1 : 0;
    const last = Math.min(page.offset + clients.length, page.total);
    elements.pageInfo.textContent = `${num(first)}–${num(last)} من ${num(page.total)}`;
    elements.previous.disabled = page.offset <= 0;
    elements.next.disabled = page.offset + clients.length >= page.total;
  }

  function renderTasks(tasks) {
    elements.tasks.innerHTML = (tasks || []).map(task => `
      <article class="listitem">
        <div class="center-task-heading"><b>${esc(task.title || 'متابعة')}</b>${pill('متأخرة', 'bad')}</div>
        <div>${esc(task.client_name || '—')} · ${esc(task.phone || '—')}</div>
        <small class="muted">موعدها ${esc(fmtDate(task.due_at))} · المسؤول ${esc(task.assigned_name || 'غير محدد')}</small>
        <button class="btn sm" type="button" data-open-client="${Number(task.client_id)}">فتح ملف العميل</button>
      </article>`).join('') || '<div class="empty">لا توجد مهام متأخرة. أحسنت!</div>';
  }

  function renderPayments(payments) {
    const canReview = ['admin', 'super_admin'].includes(role);
    elements.payments.innerHTML = (payments || []).map(payment => `
      <article class="listitem">
        <div class="center-task-heading">
          <b>${esc(payment.client_name || '—')}</b>
          ${pill('بانتظار المراجعة', 'warn')}
        </div>
        <div>${money(payment.amount)} · ${esc(payment.payment_date || '—')} · ${esc(payment.method || '—')}</div>
        <small class="muted">سجله ${esc(payment.recorded_by || 'موظف غير معروف')}${payment.reference_no ? ` · مرجع ${esc(payment.reference_no)}` : ''}</small>
        <div class="center-row-actions">
          <button class="btn sm" type="button" data-open-client="${Number(payment.client_id)}">ملف العميل</button>
          ${canReview ? `<button class="btn sm ok" type="button" data-review-payment="${Number(payment.id)}" data-decision="approved">اعتماد</button>
            <button class="btn sm danger" type="button" data-review-payment="${Number(payment.id)}" data-decision="rejected">رفض</button>` : ''}
        </div>
      </article>`).join('') || '<div class="empty">لا توجد تحصيلات بانتظار المراجعة.</div>';
  }

  function renderActivity(activities) {
      const labels = { call: 'مكالمة', visit: 'زيارة' };
      elements.activity.innerHTML = (activities || []).map(item => `
        <article class="listitem">
          <div class="center-task-heading">
            <b>${esc(labels[item.activity_type] || 'إجراء')}</b>
            ${pill(item.status || 'تم التسجيل', item.activity_type === 'visit' ? 'ok' : 'warn')}
          </div>
          <div><b>${esc(item.client_name || '—')}</b> · ${esc(item.phone || '—')}</div>
          <small class="muted">${esc(item.employee_name || 'موظف')} · ${esc(fmtDate(item.activity_at))}</small>
          ${item.details ? `<div class="center-activity-details">${esc(item.details)}</div>` : ''}
          <button class="btn sm" type="button" data-open-client="${Number(item.client_id)}">فتح ملف العميل</button>
        </article>`).join('') || '<div class="empty">ستظهر هنا إجراءات الموظفين على عملاء الدورة الحالية.</div>';
  }

  async function loadCenter() {
    const requestId = ++page.requestId;
    elements.status.textContent = 'جاري تحديث بيانات المركز…';
    elements.status.classList.remove('error');
    const query = new URLSearchParams({
      q: elements.search.value.trim(),
      stage: elements.stage.value,
      delay: elements.delay.value,
      limit: String(PAGE_SIZE),
      offset: String(page.offset),
    });
    try {
      const data = await api(`control_center_v7?${query.toString()}`);
      if (requestId !== page.requestId) return;
      renderKpis(data);
      renderStages(data.stages);
      renderQueue(data);
      renderTasks(data.overdue_tasks);
      renderPayments(data.pending_payments);
      renderActivity(data.recent_activity);
      elements.status.textContent = '';
      elements.updated.textContent = `آخر تحديث: ${new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })}`;
    } catch (error) {
      if (requestId !== page.requestId) return;
      showError(error);
      elements.rows.innerHTML = '<tr><td colspan="5" class="empty">تعذر تحميل الحالات. حاول التحديث مرة أخرى.</td></tr>';
      elements.tasks.innerHTML = '<div class="empty">تعذر تحميل المتابعات.</div>';
      elements.payments.innerHTML = '<div class="empty">تعذر تحميل التحصيلات.</div>';
      elements.activity.innerHTML = '<div class="empty">تعذر تحميل إجراءات الموظفين.</div>';
    }
  }

  document.getElementById('refreshCenter').addEventListener('click', loadCenter);
  document.getElementById('queueFilters').addEventListener('submit', event => {
    event.preventDefault();
    page.offset = 0;
    loadCenter();
  });
  document.getElementById('clearFilters').addEventListener('click', () => {
    elements.search.value = '';
    elements.stage.value = '';
    elements.delay.value = '';
    page.offset = 0;
    loadCenter();
  });
  for (const control of [elements.stage, elements.delay]) {
    control.addEventListener('change', () => {
      page.offset = 0;
      loadCenter();
    });
  }
  elements.search.addEventListener('input', () => {
    clearTimeout(page.timer);
    page.timer = setTimeout(() => {
      page.offset = 0;
      loadCenter();
    }, 300);
  });
  elements.previous.addEventListener('click', () => {
    page.offset = Math.max(0, page.offset - PAGE_SIZE);
    loadCenter();
  });
  elements.next.addEventListener('click', () => {
    if (page.offset + PAGE_SIZE < page.total) {
      page.offset += PAGE_SIZE;
      loadCenter();
    }
  });
  document.getElementById('page').addEventListener('click', async event => {
    const clientButton = event.target.closest('[data-open-client]');
    if (clientButton) {
      openClient(Number(clientButton.dataset.openClient));
      return;
    }
    const reviewButton = event.target.closest('[data-review-payment]');
    if (!reviewButton) return;
    const decision = reviewButton.dataset.decision;
    const reason = decision === 'rejected'
      ? prompt('اكتب سبب رفض التحصيل:')
      : '';
    if (decision === 'rejected' && (reason === null || !reason.trim())) return;
    const confirmation = decision === 'approved'
      ? confirm('هل تريد اعتماد هذا التحصيل؟')
      : confirm('هل تريد رفض التحصيل مع حفظ سبب الرفض؟');
    if (!confirmation) return;
    reviewButton.disabled = true;
    try {
      const result = await api('review_collection_payment', {
        method: 'POST',
        body: { payment_id: Number(reviewButton.dataset.reviewPayment), decision, reason: reason || '' },
      });
      toast(result.message || 'تم تحديث حالة التحصيل');
      await loadCenter();
    } catch (error) {
      reviewButton.disabled = false;
      showError(error);
    }
  });

  document.title = 'مركز عمليات التحصيل';
  guard(['admin', 'super_admin', 'collector', 'data_entry']).then(user => {
    if (!user) return;
    document.getElementById('userName').textContent = user.full_name || user.username || 'المستخدم';
    document.getElementById('userRole').textContent = roleLabel(user.role);
    document.getElementById('avatar').textContent = (user.full_name || user.username || 'م').trim().charAt(0);
    loadCenter();
  });
})();
