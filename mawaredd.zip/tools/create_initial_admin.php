<?php
if (PHP_SAPI !== 'cli') {
    http_response_code(404);
    exit;
}

require_once dirname(__DIR__) . '/db.php';

$username = trim((string)getenv('MAWARED_INITIAL_ADMIN_USERNAME'));
$fullName = trim((string)getenv('MAWARED_INITIAL_ADMIN_NAME'));
$password = (string)getenv('MAWARED_INITIAL_ADMIN_PASSWORD');

if (!preg_match('/^[A-Za-z0-9_.\-]{3,50}$/', $username)) {
    fwrite(STDERR, "Set MAWARED_INITIAL_ADMIN_USERNAME to 3-50 English letters, digits, dots, underscores, or hyphens.\n");
    exit(1);
}
$fullNameLength = preg_match_all('/./us', $fullName);
if ($fullName === '' || $fullNameLength === false || $fullNameLength > 255) {
    fwrite(STDERR, "Set MAWARED_INITIAL_ADMIN_NAME to the administrator's name (up to 255 characters).\n");
    exit(1);
}
if (strlen($password) < 12) {
    fwrite(STDERR, "Set MAWARED_INITIAL_ADMIN_PASSWORD to a password of at least 12 characters.\n");
    exit(1);
}

$pdo = DB::conn();
$userCount = (int)$pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();
if ($userCount !== 0) {
    fwrite(STDERR, "The users table is not empty; refusing to create or replace an administrator.\n");
    exit(1);
}

$insert = $pdo->prepare(
    "INSERT INTO users (username, password_hash, full_name, role, is_active)
     VALUES (?, ?, ?, 'super_admin', 1)"
);
$insert->execute([$username, password_hash($password, PASSWORD_DEFAULT), $fullName]);
$id = (int)$pdo->lastInsertId();
unset($password);

fwrite(STDOUT, "Initial super administrator created (id {$id}, username {$username}). Remove the temporary password environment variable now.\n");
